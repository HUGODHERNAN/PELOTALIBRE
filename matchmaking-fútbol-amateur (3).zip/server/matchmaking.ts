import { User, Position } from '../src/types';

interface MatchmakingPlayer {
  id: string;
  name: string;
  preferredPosition: Position;
  skillRating: number;
}

/**
 * Balanced Matchmaking Algorithm
 * Groups players into two balanced teams (Team A and Team B)
 * considering both their Skill Rating (SR) and preferred positions.
 */
export function balanceTeams(players: MatchmakingPlayer[]): { teamA: string[]; teamB: string[] } {
  const teamA: string[] = [];
  const teamB: string[] = [];

  if (players.length === 0) {
    return { teamA, teamB };
  }

  // 1. Group players by preferred position
  const positions: Record<Position, MatchmakingPlayer[]> = {
    GK: [],
    DEF: [],
    MID: [],
    FWD: [],
  };

  players.forEach((player) => {
    positions[player.preferredPosition].push(player);
  });

  // 2. Sort players in each position group by SR descending
  // This ensures high-skilled players are distributed first in their respective positions
  Object.keys(positions).forEach((pos) => {
    positions[pos as Position].sort((a, b) => b.skillRating - a.skillRating);
  });

  // Keep track of current total SR for each team to balance them dynamically
  let totalSRA = 0;
  let totalSRB = 0;

  // Position distribution order: GK (most critical), DEF, MID, FWD
  const positionOrder: Position[] = ['GK', 'DEF', 'MID', 'FWD'];

  positionOrder.forEach((pos) => {
    const group = positions[pos];
    
    group.forEach((player) => {
      // Balance criteria: Assign player to the team with lower total SR to keep things even.
      // If SR is equal, balance the team sizes.
      const assignToA = totalSRA === totalSRB 
        ? teamA.length <= teamB.length 
        : totalSRA < totalSRB;

      if (assignToA) {
        teamA.push(player.id);
        totalSRA += player.skillRating;
      } else {
        teamB.push(player.id);
        totalSRB += player.skillRating;
      }
    });
  });

  return { teamA, teamB };
}

/**
 * Calculates updated Skill Rating (SR) for players after a match.
 * Uses an Elo-like rating adjustment based on actual score and SR difference.
 * 
 * @param teamASR Average SR of Team A
 * @param teamBSR Average SR of Team B
 * @param scoreA Score of Team A
 * @param scoreB Score of Team B
 * @returns Object with SR change for winners, losers, or draw
 */
export function calculateSRChanges(
  teamASR: number,
  teamBSR: number,
  scoreA: number,
  scoreB: number
): { changeA: number; changeB: number } {
  // Base K-Factor for rating adjustment
  const K = 40;
  
  // Calculate expected outcome for Team A (between 0 and 1)
  const expectedA = 1 / (1 + Math.pow(10, (teamBSR - teamASR) / 400));
  const expectedB = 1 - expectedA;

  // Actual outcome for Team A
  let actualA = 0.5; // Draw
  if (scoreA > scoreB) {
    actualA = 1; // Win
  } else if (scoreA < scoreB) {
    actualA = 0; // Loss
  }

  const actualB = 1 - actualA;

  // Calculate rating changes
  let changeA = Math.round(K * (actualA - expectedA));
  let changeB = Math.round(K * (actualB - expectedB));

  // If there's a large score difference, we can apply a slight multiplier for goal difference
  const goalDiff = Math.abs(scoreA - scoreB);
  if (goalDiff > 1 && scoreA !== scoreB) {
    const multiplier = 1 + (goalDiff - 1) * 0.15;
    changeA = Math.round(changeA * multiplier);
    changeB = Math.round(changeB * multiplier);
  }

  // Ensure minimum changes so victories always yield some gain
  if (scoreA > scoreB) {
    changeA = Math.max(changeA, 10);
    changeB = Math.min(changeB, -10);
  } else if (scoreA < scoreB) {
    changeA = Math.min(changeA, -10);
    changeB = Math.max(changeB, 10);
  } else {
    // Draw
    if (teamASR > teamBSR + 50) {
      // High-skilled team drew with low-skilled: minor loss for high, minor gain for low
      changeA = Math.min(changeA, -5);
      changeB = Math.max(changeB, 5);
    } else if (teamBSR > teamASR + 50) {
      changeA = Math.max(changeA, 5);
      changeB = Math.min(changeB, -5);
    } else {
      // Balanced draw
      changeA = 0;
      changeB = 0;
    }
  }

  return { changeA, changeB };
}
