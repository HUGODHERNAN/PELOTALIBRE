import { createClient, SupabaseClient } from '@supabase/supabase-js';

let supabaseClient: SupabaseClient | null = null;

/**
 * Safely retrieves the Supabase client if configured.
 * Does not crash on startup if credentials are not yet defined.
 */
export function getSupabase(): SupabaseClient | null {
  if (supabaseClient) return supabaseClient;

  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_ANON_KEY || process.env.SUPABASE_KEY;

  if (!url || !key) {
    console.log('Supabase: SUPABASE_URL or SUPABASE_ANON_KEY is not configured yet. Falling back to local file database.');
    return null;
  }

  try {
    supabaseClient = createClient(url, key, {
      auth: {
        persistSession: false,
        autoRefreshToken: false
      }
    });
    console.log('Supabase: Client initialized successfully.');
    return supabaseClient;
  } catch (err) {
    console.error('Supabase: Failed to initialize client:', err);
    return null;
  }
}

/**
 * Check connection status and if required tables exist
 */
export async function checkSupabaseStatus() {
  const client = getSupabase();
  if (!client) {
    return {
      connected: false,
      reason: 'No configurado en .env o variables de entorno',
      tables: { users: false, rooms: false, messages: false, history: false }
    };
  }

  const tables = {
    users: false,
    rooms: false,
    messages: false,
    history: false
  };

  let connected = false;
  let reason = '';

  try {
    // Check users table
    const { error: userError } = await client.from('users').select('id').limit(1);
    tables.users = !userError || userError.code !== 'PGRST116' && userError.code !== '42P01';

    // Check rooms table
    const { error: roomError } = await client.from('rooms').select('id').limit(1);
    tables.rooms = !roomError || roomError.code !== '42P01';

    // Check messages table
    const { error: msgError } = await client.from('messages').select('id').limit(1);
    tables.messages = !msgError || msgError.code !== '42P01';

    // Check history table
    const { error: histError } = await client.from('history').select('id').limit(1);
    tables.history = !histError || histError.code !== '42P01';

    connected = true;
    if (!tables.users || !tables.rooms || !tables.messages || !tables.history) {
      reason = 'Faltan tablas por crear en la base de datos de Supabase.';
    } else {
      reason = 'Conexión exitosa y tablas detectadas.';
    }
  } catch (err: any) {
    connected = false;
    reason = `Error al conectar: ${err.message || err}`;
  }

  return {
    connected,
    reason,
    tables
  };
}

/**
 * Returns SQL Script to initialize tables in Supabase SQL Editor
 */
export function getSupabaseSQLScript(): string {
  return `-- ==========================================
-- SQL SETUP SCRIPT FOR PELOTALIMPIA (STRIKER.FORCE)
-- Copy and run this script in your Supabase SQL Editor!
-- ==========================================

-- 1. Create Users Table
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  "preferredPosition" TEXT NOT NULL,
  "skillRating" INTEGER DEFAULT 1000,
  "matchesPlayed" INTEGER DEFAULT 0,
  "wins" INTEGER DEFAULT 0,
  "losses" INTEGER DEFAULT 0,
  "draws" INTEGER DEFAULT 0,
  department TEXT,
  province TEXT,
  district TEXT,
  "passwordHash" TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Create Rooms Table
CREATE TABLE IF NOT EXISTS rooms (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  "creatorId" TEXT NOT NULL,
  "creatorName" TEXT NOT NULL,
  date TEXT NOT NULL,
  time TEXT NOT NULL,
  "pitchType" TEXT NOT NULL,
  "maxPlayers" INTEGER NOT NULL,
  "expectedSR" INTEGER NOT NULL,
  players JSONB DEFAULT '[]'::jsonb,
  "teamA" JSONB DEFAULT '[]'::jsonb,
  "teamB" JSONB DEFAULT '[]'::jsonb,
  state TEXT DEFAULT 'lobby',
  "createdAt" TEXT NOT NULL,
  department TEXT,
  province TEXT,
  district TEXT,
  "mapsUrl" TEXT,
  "captainA" TEXT,
  "captainB" TEXT,
  "scoreA" INTEGER,
  "scoreB" INTEGER,
  "scoreApprovalState" TEXT DEFAULT 'none',
  "pendingScoreA" INTEGER,
  "pendingScoreB" INTEGER
);

-- 3. Create Messages Table
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  "roomId" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "userName" TEXT NOT NULL,
  text TEXT NOT NULL,
  "createdAt" TEXT NOT NULL
);

-- 4. Create History Table
CREATE TABLE IF NOT EXISTS history (
  id TEXT PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "roomId" TEXT NOT NULL,
  title TEXT NOT NULL,
  date TEXT NOT NULL,
  "pitchType" TEXT NOT NULL,
  "scoreA" INTEGER NOT NULL,
  "scoreB" INTEGER NOT NULL,
  "teamA" JSONB DEFAULT '[]'::jsonb,
  "teamB" JSONB DEFAULT '[]'::jsonb,
  result TEXT NOT NULL,
  "srChange" INTEGER NOT NULL,
  timestamp TEXT NOT NULL
);

-- 5. Disable Row Level Security (or create wide policies for ease of demo)
ALTER TABLE users DISABLE ROW LEVEL SECURITY;
ALTER TABLE rooms DISABLE ROW LEVEL SECURITY;
ALTER TABLE messages DISABLE ROW LEVEL SECURITY;
ALTER TABLE history DISABLE ROW LEVEL SECURITY;

-- Note: In production you would enable RLS and add policies. For an agile build,
-- we bypass RLS so the anon key can perform database updates seamlessly.
`;
}
