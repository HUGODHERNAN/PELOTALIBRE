import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import { randomUUID } from 'crypto';
import { User, Room, Message, MatchHistoryItem, Position, PitchType, PlayerInfo } from '../src/types';
import { balanceTeams, calculateSRChanges } from './matchmaking';
import { getSupabase } from './supabase';

const DB_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'database.json');

interface DatabaseSchema {
  users: Record<string, User & { passwordHash: string }>;
  rooms: Record<string, Room>;
  messages: Message[];
  history: MatchHistoryItem[];
}

class Database {
  private data: DatabaseSchema = {
    users: {},
    rooms: {},
    messages: [],
    history: [],
  };

  constructor() {
    this.init();
  }

  private init() {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }

    if (fs.existsSync(DB_FILE)) {
      try {
        const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
        this.data = JSON.parse(fileContent);
        // Ensure all collections exist
        if (!this.data.users) this.data.users = {};
        if (!this.data.rooms) this.data.rooms = {};
        if (!this.data.messages) this.data.messages = [];
        if (!this.data.history) this.data.history = [];
      } catch (err) {
        console.error('Error reading database, initializing empty:', err);
        this.save();
      }
    } else {
      this.save();
    }
    // Pull and sync from Supabase asynchronously
    this.syncPullFromSupabase().catch((err) => {
      console.error('Failed to run initial sync pull:', err);
    });
  }

  private save() {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error writing to database:', err);
    }
  }

  // --- USER OPERATIONS ---

  public createUser(
    email: string,
    passwordPlain: string,
    name: string,
    preferredPosition: Position,
    department?: string,
    province?: string,
    district?: string
  ): User {
    const emailLower = email.toLowerCase().trim();
    
    // Check if user exists
    const existing = Object.values(this.data.users).find((u) => u.email.toLowerCase() === emailLower);
    if (existing) {
      throw new Error('El correo electrónico ya está registrado.');
    }

    const id = 'user_' + randomUUID();
    const passwordHash = bcrypt.hashSync(passwordPlain, 10);

    const newUser: User & { passwordHash: string } = {
      id,
      email: emailLower,
      name,
      preferredPosition,
      skillRating: 1000, // Default SR
      matchesPlayed: 0,
      wins: 0,
      losses: 0,
      draws: 0,
      department,
      province,
      district,
      passwordHash,
    };

    this.data.users[id] = newUser;
    this.save();
    this.syncUserToSupabase(newUser).catch(err => console.error('Failed user sync:', err));

    const { passwordHash: _, ...userWithoutPassword } = newUser;
    return userWithoutPassword;
  }

  public async getUserByEmail(email: string): Promise<(User & { passwordHash: string }) | null> {
    const emailLower = email.toLowerCase().trim();
    const found = Object.values(this.data.users).find((u) => u.email.toLowerCase() === emailLower);
    if (found) return found;

    const supabase = getSupabase();
    if (!supabase) return null;

    try {
      console.log(`Supabase: User with email ${emailLower} not found in memory. Attempting to fetch from cloud...`);
      const { data: u, error } = await supabase.from('users').select('*').eq('email', emailLower).single();
      if (error || !u) {
        console.log(`Supabase: User with email ${emailLower} not found in cloud either.`);
        return null;
      }

      const dbUser = {
        id: u.id,
        email: u.email,
        name: u.name,
        preferredPosition: u.preferredPosition as Position,
        skillRating: u.skillRating,
        matchesPlayed: u.matchesPlayed,
        wins: u.wins,
        losses: u.losses,
        draws: u.draws,
        department: u.department || undefined,
        province: u.province || undefined,
        district: u.district || undefined,
        passwordHash: u.passwordHash,
      };

      this.data.users[u.id] = dbUser;
      this.save();

      return dbUser;
    } catch (err: any) {
      console.error(`Supabase: Error fetching user by email ${emailLower}:`, err.message || err);
      return null;
    }
  }

  public getUserById(id: string): User | null {
    const found = this.data.users[id];
    if (!found) return null;
    const { passwordHash: _, ...userWithoutPassword } = found;
    return userWithoutPassword;
  }

  public updateUserProfile(
    id: string,
    name: string,
    preferredPosition: Position,
    department?: string,
    province?: string,
    district?: string
  ): User {
    const user = this.data.users[id];
    if (!user) {
      throw new Error('Usuario no encontrado');
    }

    user.name = name;
    user.preferredPosition = preferredPosition;
    user.department = department;
    user.province = province;
    user.district = district;
    
    // Also update any rooms where they are the creator name
    Object.values(this.data.rooms).forEach((room) => {
      if (room.creatorId === id) {
        room.creatorName = name;
        this.syncRoomToSupabase(room).catch(err => console.error('Failed room creator rename sync:', err));
      }
    });

    this.save();
    this.syncUserToSupabase(user).catch(err => console.error('Failed user profile update sync:', err));

    const { passwordHash: _, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }

  // --- ROOM OPERATIONS ---

  public createRoom(
    title: string,
    creatorId: string,
    date: string,
    time: string,
    pitchType: PitchType,
    maxPlayers: number,
    expectedSR: number,
    department?: string,
    province?: string,
    district?: string,
    mapsUrl?: string
  ): Room {
    const creator = this.getUserById(creatorId);
    if (!creator) {
      throw new Error('Creador no encontrado');
    }

    const id = 'room_' + randomUUID();
    
    const newRoom: Room = {
      id,
      title,
      creatorId,
      creatorName: creator.name,
      date,
      time,
      pitchType,
      maxPlayers,
      expectedSR,
      players: [creatorId], // Creator joins automatically
      teamA: [creatorId],   // Initial team balancing
      teamB: [],
      state: 'lobby',
      createdAt: new Date().toISOString(),
      department,
      province,
      district,
      mapsUrl,
    };

    this.data.rooms[id] = newRoom;
    this.save();
    this.syncRoomToSupabase(newRoom).catch(err => console.error('Failed room create sync:', err));
    return newRoom;
  }

  public getRooms(): Room[] {
    return Object.values(this.data.rooms);
  }

  public getRoom(id: string): Room | null {
    return this.data.rooms[id] || null;
  }

  public async ensureRoomLoaded(roomId: string): Promise<Room | null> {
    if (this.data.rooms[roomId]) {
      return this.data.rooms[roomId];
    }

    const supabase = getSupabase();
    if (!supabase) return null;

    try {
      console.log(`Supabase: Room ${roomId} not found in memory. Attempting to fetch from cloud...`);
      const { data: r, error } = await supabase.from('rooms').select('*').eq('id', roomId).single();
      if (error || !r) {
        console.log(`Supabase: Room ${roomId} not found in cloud either.`);
        return null;
      }

      const players = typeof r.players === 'string' ? JSON.parse(r.players) : r.players;
      const teamA = typeof r.teamA === 'string' ? JSON.parse(r.teamA) : r.teamA;
      const teamB = typeof r.teamB === 'string' ? JSON.parse(r.teamB) : r.teamB;

      const room: Room = {
        id: r.id,
        title: r.title,
        creatorId: r.creatorId,
        creatorName: r.creatorName,
        date: r.date,
        time: r.time,
        pitchType: r.pitchType as PitchType,
        maxPlayers: r.maxPlayers,
        expectedSR: r.expectedSR,
        players: Array.isArray(players) ? players : [],
        teamA: Array.isArray(teamA) ? teamA : [],
        teamB: Array.isArray(teamB) ? teamB : [],
        state: r.state as any,
        createdAt: r.createdAt,
        department: r.department || undefined,
        province: r.province || undefined,
        district: r.district || undefined,
        mapsUrl: r.mapsUrl || undefined,
        captainA: r.captainA || undefined,
        captainB: r.captainB || undefined,
        scoreA: r.scoreA !== null && r.scoreA !== undefined ? r.scoreA : undefined,
        scoreB: r.scoreB !== null && r.scoreB !== undefined ? r.scoreB : undefined,
        scoreApprovalState: r.scoreApprovalState as any,
        pendingScoreA: r.pendingScoreA !== null && r.pendingScoreA !== undefined ? r.pendingScoreA : undefined,
        pendingScoreB: r.pendingScoreB !== null && r.pendingScoreB !== undefined ? r.pendingScoreB : undefined,
      };

      this.data.rooms[roomId] = room;
      this.save();
      return room;
    } catch (err: any) {
      console.error(`Supabase: Error ensuring room loaded:`, err.message || err);
      return null;
    }
  }

  public async ensureUserLoaded(userId: string): Promise<User | null> {
    if (this.data.users[userId]) {
      const { passwordHash: _, ...userWithoutPassword } = this.data.users[userId];
      return userWithoutPassword;
    }

    const supabase = getSupabase();
    if (!supabase) return null;

    try {
      console.log(`Supabase: User ${userId} not found in memory. Attempting to fetch from cloud...`);
      const { data: u, error } = await supabase.from('users').select('*').eq('id', userId).single();
      if (error || !u) {
        console.log(`Supabase: User ${userId} not found in cloud either.`);
        return null;
      }

      this.data.users[userId] = {
        id: u.id,
        email: u.email,
        name: u.name,
        preferredPosition: u.preferredPosition as Position,
        skillRating: u.skillRating,
        matchesPlayed: u.matchesPlayed,
        wins: u.wins,
        losses: u.losses,
        draws: u.draws,
        department: u.department || undefined,
        province: u.province || undefined,
        district: u.district || undefined,
        passwordHash: u.passwordHash,
      };
      this.save();
      const { passwordHash: _, ...userWithoutPassword } = this.data.users[userId];
      return userWithoutPassword;
    } catch (err: any) {
      console.error(`Supabase: Error ensuring user loaded:`, err.message || err);
      return null;
    }
  }

  /**
   * Helper to recalculate teams inside a room lobby
   */
  private rebalanceRoomTeams(room: Room) {
    if (room.state !== 'lobby') return;

    // Fetch details of all players currently in the room
    const playersInfo = room.players
      .map((pid) => this.getUserById(pid))
      .filter((u): u is User => u !== null)
      .map((u) => ({
        id: u.id,
        name: u.name,
        preferredPosition: u.preferredPosition,
        skillRating: u.skillRating,
      }));

    const balanced = balanceTeams(playersInfo);
    room.teamA = balanced.teamA;
    room.teamB = balanced.teamB;
  }

  public joinRoom(roomId: string, userId: string): Room {
    const room = this.data.rooms[roomId];
    if (!room) {
      throw new Error('Sala no encontrada');
    }

    if (room.state !== 'lobby') {
      throw new Error('El partido ya ha comenzado o finalizado');
    }

    if (room.players.includes(userId)) {
      return room; // Already in the room
    }

    if (room.players.length >= room.maxPlayers) {
      throw new Error('La sala ya está llena');
    }

    room.players.push(userId);
    this.rebalanceRoomTeams(room);
    this.save();
    this.syncRoomToSupabase(room).catch(err => console.error('Failed room join sync:', err));
    return room;
  }

  public leaveRoom(roomId: string, userId: string): Room | null {
    const room = this.data.rooms[roomId];
    if (!room) {
      throw new Error('Sala no encontrada');
    }

    if (room.state !== 'lobby') {
      throw new Error('No puedes salir de un partido que ya ha comenzado');
    }

    room.players = room.players.filter((pid) => pid !== userId);
    
    // If room has no human players left, delete it automatically
    const humanPlayers = room.players.filter((pid) => !pid.startsWith('bot_'));
    if (humanPlayers.length === 0) {
      delete this.data.rooms[roomId];
      // Also clean up messages for this room
      this.data.messages = this.data.messages.filter((m) => m.roomId !== roomId);
      this.save();
      this.deleteRoomFromSupabase(roomId).catch(err => console.error('Failed room leave-deletion sync:', err));
      return null;
    }

    // If the creator leaves, assign a new creator from remaining players
    if (room.creatorId === userId) {
      const nextCreatorId = room.players[0];
      const nextCreator = this.getUserById(nextCreatorId);
      if (nextCreator) {
        room.creatorId = nextCreatorId;
        room.creatorName = nextCreator.name;
      }
    }

    this.rebalanceRoomTeams(room);
    this.save();
    this.syncRoomToSupabase(room).catch(err => console.error('Failed room leave sync:', err));
    return room;
  }

  public deleteRoom(roomId: string, userId: string): void {
    const room = this.data.rooms[roomId];
    if (!room) {
      throw new Error('Sala no encontrada');
    }
    if (room.creatorId !== userId) {
      throw new Error('Solo el creador de la sala puede eliminarla');
    }
    if (room.state === 'finished') {
      throw new Error('No se puede eliminar un partido que ya ha sido finalizado.');
    }
    delete this.data.rooms[roomId];
    this.data.messages = this.data.messages.filter((m) => m.roomId !== roomId);
    this.save();
    this.deleteRoomFromSupabase(roomId).catch(err => console.error('Failed room delete sync:', err));
  }

  public fillRoomWithBots(roomId: string, userId: string): Room {
    const room = this.data.rooms[roomId];
    if (!room) {
      throw new Error('Sala no encontrada');
    }

    if (room.creatorId !== userId) {
      throw new Error('Solo el creador de la sala puede llenar con bots');
    }

    if (room.state !== 'lobby') {
      throw new Error('La sala debe estar en modo lobby');
    }

    const positions: Position[] = ['GK', 'DEF', 'MID', 'FWD'];
    const botNames = [
      'Leo Messi (Bot)', 'Cris Ronaldo (Bot)', 'Kylian M. (Bot)', 'Erling H. (Bot)',
      'Luka M. (Bot)', 'Kevin DB. (Bot)', 'Virgil V. (Bot)', 'Pedri (Bot)',
      'Gavi (Bot)', 'Jude B. (Bot)', 'Neymar Jr (Bot)', 'Mo Salah (Bot)',
      'Robert L. (Bot)', 'Karim B. (Bot)', 'Son HM. (Bot)', 'Antoine G. (Bot)'
    ];

    const currentPlayersCount = room.players.length;
    const maxToFill = room.maxPlayers - currentPlayersCount;

    if (maxToFill <= 0) {
      throw new Error('La sala ya está llena');
    }

    for (let i = 0; i < maxToFill; i++) {
      const botId = 'bot_' + randomUUID();
      const nameBase = botNames[Math.floor(Math.random() * botNames.length)];
      const botName = `${nameBase} #${Math.floor(Math.random() * 900) + 100}`;
      const preferredPosition = positions[Math.floor(Math.random() * positions.length)];
      const skillRating = Math.floor(Math.random() * 500) + 850; // Random SR 850 - 1350

      const botUser = {
        id: botId,
        email: `${botId}@futsalbot.local`,
        name: botName,
        preferredPosition,
        skillRating,
        matchesPlayed: Math.floor(Math.random() * 20) + 5,
        wins: Math.floor(Math.random() * 10) + 2,
        losses: Math.floor(Math.random() * 8) + 2,
        draws: Math.floor(Math.random() * 4),
        passwordHash: '',
      };

      this.data.users[botId] = botUser;
      room.players.push(botId);
      this.syncUserToSupabase(botUser).catch(err => console.error('Failed bot user sync:', err));
    }

    this.rebalanceRoomTeams(room);
    this.save();
    this.syncRoomToSupabase(room).catch(err => console.error('Failed room fill-bots sync:', err));
    return room;
  }

  private selectCaptainForTeam(team: string[]): string | undefined {
    if (team.length === 0) return undefined;
    const humanPlayers = team.filter((pid) => !pid.startsWith('bot_'));
    if (humanPlayers.length > 0) {
      return humanPlayers[Math.floor(Math.random() * humanPlayers.length)];
    }
    return team[0];
  }

  public startMatch(roomId: string, creatorId: string): Room {
    const room = this.data.rooms[roomId];
    if (!room) {
      throw new Error('Sala no encontrada');
    }

    if (room.creatorId !== creatorId) {
      throw new Error('Solo el creador puede iniciar el partido');
    }

    if (room.state !== 'lobby') {
      throw new Error('El partido ya está iniciado o finalizado');
    }

    if (room.players.length < 2) {
      throw new Error('Se necesitan al menos 2 jugadores para iniciar el partido');
    }

    // Make sure we lock the final team balance
    this.rebalanceRoomTeams(room);

    // Explicitly guarantee captains are set to real players
    if (!room.captainA && room.teamA.length > 0) {
      room.captainA = this.selectCaptainForTeam(room.teamA);
    }
    if (!room.captainB && room.teamB.length > 0) {
      room.captainB = this.selectCaptainForTeam(room.teamB);
    }

    room.state = 'started';
    room.scoreApprovalState = 'none';
    this.save();
    this.syncRoomToSupabase(room).catch(err => console.error('Failed start match sync:', err));
    return room;
  }

  public proposeMatchScore(roomId: string, userId: string, scoreA: number, scoreB: number): Room {
    const room = this.data.rooms[roomId];
    if (!room) {
      throw new Error('Sala no encontrada');
    }

    if (room.state !== 'started') {
      throw new Error('El partido debe estar iniciado para poder registrar un resultado');
    }

    // Ensure captains are set if somehow missing (real players preferred)
    if (!room.captainA && room.teamA.length > 0) room.captainA = this.selectCaptainForTeam(room.teamA);
    if (!room.captainB && room.teamB.length > 0) room.captainB = this.selectCaptainForTeam(room.teamB);

    // Determine which team the proposer belongs to
    const isTeamA = room.teamA.includes(userId);
    const isTeamB = room.teamB.includes(userId);

    if (!isTeamA && !isTeamB && room.creatorId !== userId) {
      throw new Error('Solo los jugadores del partido pueden proponer un resultado.');
    }

    room.pendingScoreA = scoreA;
    room.pendingScoreB = scoreB;
    room.scoreApprovalState = 'pending_approval';

    // Proposer's team immediately approves their proposal
    if (isTeamB) {
      room.captainBApproved = true;
      room.captainAApproved = false;
    } else {
      room.captainAApproved = true;
      room.captainBApproved = false;
    }

    // If the opposite team has no human players (only bots), they auto-approve
    const hasTeamAHumans = room.teamA.some(pid => !pid.startsWith('bot_'));
    const hasTeamBHumans = room.teamB.some(pid => !pid.startsWith('bot_'));

    if (isTeamB && !hasTeamAHumans) {
      room.captainAApproved = true;
    } else if (!isTeamB && !hasTeamBHumans) {
      room.captainBApproved = true;
    }

    // Check if both sides have approved right away
    if (room.captainAApproved && room.captainBApproved) {
      // Finalize right away
      room.state = 'finished';
      room.scoreA = scoreA;
      room.scoreB = scoreB;
      room.scoreApprovalState = 'approved';

      // Fetch player objects
      const playersA = room.teamA.map((pid) => this.data.users[pid]).filter(Boolean);
      const playersB = room.teamB.map((pid) => this.data.users[pid]).filter(Boolean);

      // Calculate average SRs
      const avgSRA = playersA.length > 0
        ? playersA.reduce((sum, p) => sum + p.skillRating, 0) / playersA.length
        : 1000;
      
      const avgSRB = playersB.length > 0
        ? playersB.reduce((sum, p) => sum + p.skillRating, 0) / playersB.length
        : 1000;

      // Calculate SR adjustments
      const { changeA, changeB } = calculateSRChanges(avgSRA, avgSRB, scoreA, scoreB);

      // Form player arrays for match history entry
      const mapToPlayerInfo = (u: User): PlayerInfo => ({
        id: u.id,
        name: u.name,
        preferredPosition: u.preferredPosition,
        skillRating: u.skillRating,
      });

      const teamAPlayersInfo = playersA.map(mapToPlayerInfo);
      const teamBPlayersInfo = playersB.map(mapToPlayerInfo);

      // For Team A
      playersA.forEach((player) => {
        player.matchesPlayed += 1;
        player.skillRating = Math.max(100, player.skillRating + changeA);
        
        let result: 'win' | 'loss' | 'draw' = 'draw';
        if (scoreA > scoreB) {
          player.wins += 1;
          result = 'win';
        } else if (scoreA < scoreB) {
          player.losses += 1;
          result = 'loss';
        } else {
          player.draws += 1;
        }

        const historyItem: MatchHistoryItem = {
          id: 'hist_' + randomUUID(),
          userId: player.id,
          roomId: room.id,
          title: room.title,
          date: room.date,
          pitchType: room.pitchType,
          scoreA,
          scoreB,
          teamA: teamAPlayersInfo,
          teamB: teamBPlayersInfo,
          result,
          srChange: changeA,
          timestamp: new Date().toISOString(),
        };
        
        this.data.history.push(historyItem);
        this.syncUserToSupabase(player).catch(err => console.error('Failed user match finish sync:', err));
        this.syncHistoryToSupabase(historyItem).catch(err => console.error('Failed history sync:', err));
      });

      // For Team B
      playersB.forEach((player) => {
        player.matchesPlayed += 1;
        player.skillRating = Math.max(100, player.skillRating + changeB);
        
        let result: 'win' | 'loss' | 'draw' = 'draw';
        if (scoreB > scoreA) {
          player.wins += 1;
          result = 'win';
        } else if (scoreB < scoreA) {
          player.losses += 1;
          result = 'loss';
        } else {
          player.draws += 1;
        }

        const historyItem: MatchHistoryItem = {
          id: 'hist_' + randomUUID(),
          userId: player.id,
          roomId: room.id,
          title: room.title,
          date: room.date,
          pitchType: room.pitchType,
          scoreA,
          scoreB,
          teamA: teamAPlayersInfo,
          teamB: teamBPlayersInfo,
          result,
          srChange: changeB,
          timestamp: new Date().toISOString(),
        };
        
        this.data.history.push(historyItem);
        this.syncUserToSupabase(player).catch(err => console.error('Failed user match finish sync:', err));
        this.syncHistoryToSupabase(historyItem).catch(err => console.error('Failed history sync:', err));
      });

      room.pendingScoreA = undefined;
      room.pendingScoreB = undefined;
    }

    this.save();
    this.syncRoomToSupabase(room).catch(err => console.error('Failed propose score sync:', err));
    return room;
  }

  public rejectMatchScore(roomId: string, userId: string): Room {
    const room = this.data.rooms[roomId];
    if (!room) {
      throw new Error('Sala no encontrada');
    }

    if (room.state !== 'started' || room.scoreApprovalState !== 'pending_approval') {
      throw new Error('No hay un resultado pendiente de aprobación.');
    }

    const isTeamA = room.teamA.includes(userId);
    const isTeamB = room.teamB.includes(userId);

    if (!isTeamA && !isTeamB && room.creatorId !== userId) {
      throw new Error('Solo los jugadores del partido pueden rechazar el resultado.');
    }

    room.scoreApprovalState = 'rejected';
    room.pendingScoreA = undefined;
    room.pendingScoreB = undefined;
    room.captainAApproved = false;
    room.captainBApproved = false;
    this.save();
    this.syncRoomToSupabase(room).catch(err => console.error('Failed reject score sync:', err));
    return room;
  }

  public approveMatchScore(roomId: string, userId: string): Room {
    const room = this.data.rooms[roomId];
    if (!room) {
      throw new Error('Sala no encontrada');
    }

    if (room.state !== 'started' || room.scoreApprovalState !== 'pending_approval') {
      throw new Error('No hay un resultado pendiente de aprobación.');
    }

    // Ensure captains are set if somehow missing
    if (!room.captainA && room.teamA.length > 0) room.captainA = this.selectCaptainForTeam(room.teamA);
    if (!room.captainB && room.teamB.length > 0) room.captainB = this.selectCaptainForTeam(room.teamB);

    const isTeamA = room.teamA.includes(userId);
    const isTeamB = room.teamB.includes(userId);

    if (!isTeamA && !isTeamB) {
      throw new Error('Solo los jugadores del partido pueden aprobar el resultado.');
    }

    if (isTeamA) {
      room.captainAApproved = true;
    }
    if (isTeamB) {
      room.captainBApproved = true;
    }

    // Check if both sides have approved
    const hasTeamAHumans = room.teamA.some(pid => !pid.startsWith('bot_'));
    const hasTeamBHumans = room.teamB.some(pid => !pid.startsWith('bot_'));

    const teamAOk = room.captainAApproved || !hasTeamAHumans;
    const teamBOk = room.captainBApproved || !hasTeamBHumans;

    if (teamAOk && teamBOk) {
      const scoreA = room.pendingScoreA!;
      const scoreB = room.pendingScoreB!;

      room.state = 'finished';
      room.scoreA = scoreA;
      room.scoreB = scoreB;
      room.scoreApprovalState = 'approved';

      // Fetch player objects
      const playersA = room.teamA.map((pid) => this.data.users[pid]).filter(Boolean);
      const playersB = room.teamB.map((pid) => this.data.users[pid]).filter(Boolean);

      // Calculate average SRs
      const avgSRA = playersA.length > 0
        ? playersA.reduce((sum, p) => sum + p.skillRating, 0) / playersA.length
        : 1000;
      
      const avgSRB = playersB.length > 0
        ? playersB.reduce((sum, p) => sum + p.skillRating, 0) / playersB.length
        : 1000;

      // Calculate SR adjustments
      const { changeA, changeB } = calculateSRChanges(avgSRA, avgSRB, scoreA, scoreB);

      // Form player arrays for match history entry
      const mapToPlayerInfo = (u: User): PlayerInfo => ({
        id: u.id,
        name: u.name,
        preferredPosition: u.preferredPosition,
        skillRating: u.skillRating,
      });

      const teamAPlayersInfo = playersA.map(mapToPlayerInfo);
      const teamBPlayersInfo = playersB.map(mapToPlayerInfo);

      // Determine results and update each player's profile and match history
      // For Team A
      playersA.forEach((player) => {
        player.matchesPlayed += 1;
        player.skillRating = Math.max(100, player.skillRating + changeA); // Cap at 100 minimum SR
        
        let result: 'win' | 'loss' | 'draw' = 'draw';
        if (scoreA > scoreB) {
          player.wins += 1;
          result = 'win';
        } else if (scoreA < scoreB) {
          player.losses += 1;
          result = 'loss';
        } else {
          player.draws += 1;
        }

        const historyItem: MatchHistoryItem = {
          id: 'hist_' + randomUUID(),
          userId: player.id,
          roomId: room.id,
          title: room.title,
          date: room.date,
          pitchType: room.pitchType,
          scoreA,
          scoreB,
          teamA: teamAPlayersInfo,
          teamB: teamBPlayersInfo,
          result,
          srChange: changeA,
          timestamp: new Date().toISOString(),
        };
        
        this.data.history.push(historyItem);
        this.syncUserToSupabase(player).catch(err => console.error('Failed user match finish sync:', err));
        this.syncHistoryToSupabase(historyItem).catch(err => console.error('Failed history sync:', err));
      });

      // For Team B
      playersB.forEach((player) => {
        player.matchesPlayed += 1;
        player.skillRating = Math.max(100, player.skillRating + changeB);
        
        let result: 'win' | 'loss' | 'draw' = 'draw';
        if (scoreB > scoreA) {
          player.wins += 1;
          result = 'win';
        } else if (scoreB < scoreA) {
          player.losses += 1;
          result = 'loss';
        } else {
          player.draws += 1;
        }

        const historyItem: MatchHistoryItem = {
          id: 'hist_' + randomUUID(),
          userId: player.id,
          roomId: room.id,
          title: room.title,
          date: room.date,
          pitchType: room.pitchType,
          scoreA,
          scoreB,
          teamA: teamAPlayersInfo,
          teamB: teamBPlayersInfo,
          result,
          srChange: changeB,
          timestamp: new Date().toISOString(),
        };
        
        this.data.history.push(historyItem);
        this.syncUserToSupabase(player).catch(err => console.error('Failed user match finish sync:', err));
        this.syncHistoryToSupabase(historyItem).catch(err => console.error('Failed history sync:', err));
      });

      room.pendingScoreA = undefined;
      room.pendingScoreB = undefined;
    }

    this.save();
    this.syncRoomToSupabase(room).catch(err => console.error('Failed score approve sync:', err));
    return room;
  }

  // --- MESSAGE OPERATIONS ---

  public addMessage(roomId: string, userId: string, userName: string, text: string): Message {
    const room = this.data.rooms[roomId];
    if (room && room.state === 'finished' && userId !== 'system') {
      throw new Error('El chat está cerrado para partidos finalizados');
    }

    const message: Message = {
      id: 'msg_' + randomUUID(),
      roomId,
      userId,
      userName,
      text,
      createdAt: new Date().toISOString(),
    };
    
    this.data.messages.push(message);
    
    // Limit chat history length per room to keep db small (e.g., keep last 100 messages)
    const roomMessages = this.data.messages.filter((m) => m.roomId === roomId);
    if (roomMessages.length > 100) {
      const toRemove = roomMessages.slice(0, roomMessages.length - 100);
      const removeIds = new Set(toRemove.map((m) => m.id));
      this.data.messages = this.data.messages.filter((m) => !removeIds.has(m.id));
    }

    this.save();
    this.syncMessageToSupabase(message).catch(err => console.error('Failed message sync:', err));
    return message;
  }

  public getRoomMessages(roomId: string): Message[] {
    return this.data.messages.filter((m) => m.roomId === roomId);
  }

  // --- HISTORY OPERATIONS ---

  public getPlayerHistory(userId: string): MatchHistoryItem[] {
    // Return history items associated with this specific user
    return this.data.history.filter((item) => {
      if (item.userId) {
        return item.userId === userId;
      }
      // Fallback for older data without a userId
      const inTeamA = item.teamA.some((p) => p.id === userId);
      const inTeamB = item.teamB.some((p) => p.id === userId);
      return inTeamA || inTeamB;
    }).sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  }

  // --- SUPABASE SYNCHRONIZATION HELPERS ---

  private async syncPullFromSupabase() {
    const supabase = getSupabase();
    if (!supabase) return;

    try {
      console.log('Supabase: Attempting to pull and sync data from cloud tables...');
      
      // Pull users
      const { data: sUsers, error: userErr } = await supabase.from('users').select('*');
      if (userErr) {
        console.warn('Supabase: Could not pull users (tables might not exist yet):', userErr.message);
        return; // Don't proceed if tables are not found
      }

      if (sUsers && sUsers.length > 0) {
        sUsers.forEach((u: any) => {
          this.data.users[u.id] = {
            id: u.id,
            email: u.email,
            name: u.name,
            preferredPosition: u.preferredPosition as Position,
            skillRating: u.skillRating,
            matchesPlayed: u.matchesPlayed,
            wins: u.wins,
            losses: u.losses,
            draws: u.draws,
            department: u.department || undefined,
            province: u.province || undefined,
            district: u.district || undefined,
            passwordHash: u.passwordHash
          };
        });
      }

      // Pull rooms
      const { data: sRooms, error: roomErr } = await supabase.from('rooms').select('*');
      if (!roomErr && sRooms && sRooms.length > 0) {
        sRooms.forEach((r: any) => {
          const players = typeof r.players === 'string' ? JSON.parse(r.players) : r.players;
          const teamA = typeof r.teamA === 'string' ? JSON.parse(r.teamA) : r.teamA;
          const teamB = typeof r.teamB === 'string' ? JSON.parse(r.teamB) : r.teamB;

          this.data.rooms[r.id] = {
            id: r.id,
            title: r.title,
            creatorId: r.creatorId,
            creatorName: r.creatorName,
            date: r.date,
            time: r.time,
            pitchType: r.pitchType as PitchType,
            maxPlayers: r.maxPlayers,
            expectedSR: r.expectedSR,
            players: Array.isArray(players) ? players : [],
            teamA: Array.isArray(teamA) ? teamA : [],
            teamB: Array.isArray(teamB) ? teamB : [],
            state: r.state as any,
            createdAt: r.createdAt,
            department: r.department || undefined,
            province: r.province || undefined,
            district: r.district || undefined,
            mapsUrl: r.mapsUrl || undefined,
            captainA: r.captainA || undefined,
            captainB: r.captainB || undefined,
            scoreA: r.scoreA !== null ? r.scoreA : undefined,
            scoreB: r.scoreB !== null ? r.scoreB : undefined,
            scoreApprovalState: r.scoreApprovalState as any,
            pendingScoreA: r.pendingScoreA !== null ? r.pendingScoreA : undefined,
            pendingScoreB: r.pendingScoreB !== null ? r.pendingScoreB : undefined,
          };
        });
      }

      // Pull messages
      const { data: sMessages, error: msgErr } = await supabase.from('messages').select('*');
      if (!msgErr && sMessages && sMessages.length > 0) {
        this.data.messages = sMessages.map((m: any) => ({
          id: m.id,
          roomId: m.roomId,
          userId: m.userId,
          userName: m.userName,
          text: m.text,
          createdAt: m.createdAt
        }));
      }

      // Pull history
      const { data: sHistory, error: histErr } = await supabase.from('history').select('*');
      if (!histErr && sHistory && sHistory.length > 0) {
        this.data.history = sHistory.map((h: any) => {
          const teamA = typeof h.teamA === 'string' ? JSON.parse(h.teamA) : h.teamA;
          const teamB = typeof h.teamB === 'string' ? JSON.parse(h.teamB) : h.teamB;
          return {
            id: h.id,
            userId: h.userId,
            roomId: h.roomId,
            title: h.title,
            date: h.date,
            pitchType: h.pitchType as PitchType,
            scoreA: h.scoreA,
            scoreB: h.scoreB,
            teamA: Array.isArray(teamA) ? teamA : [],
            teamB: Array.isArray(teamB) ? teamB : [],
            result: h.result as any,
            srChange: h.srChange,
            timestamp: h.timestamp
          };
        });
      }

      console.log('Supabase: Cloud data loaded and merged successfully!');
      fs.writeFileSync(DB_FILE, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err: any) {
      console.error('Supabase: Error during data pull:', err.message || err);
    }
  }

  private async syncUserToSupabase(user: any) {
    const supabase = getSupabase();
    if (!supabase) return;
    try {
      const { error } = await supabase.from('users').upsert({
        id: user.id,
        email: user.email,
        name: user.name,
        preferredPosition: user.preferredPosition,
        skillRating: user.skillRating,
        matchesPlayed: user.matchesPlayed,
        wins: user.wins,
        losses: user.losses,
        draws: user.draws,
        department: user.department || null,
        province: user.province || null,
        district: user.district || null,
        passwordHash: user.passwordHash
      });
      if (error) console.error('Supabase Error updating user:', error.message);
    } catch (err) {
      console.error('Supabase Error updating user:', err);
    }
  }

  private async syncRoomToSupabase(room: any) {
    const supabase = getSupabase();
    if (!supabase) return;
    try {
      const { error } = await supabase.from('rooms').upsert({
        id: room.id,
        title: room.title,
        creatorId: room.creatorId,
        creatorName: room.creatorName,
        date: room.date,
        time: room.time,
        pitchType: room.pitchType,
        maxPlayers: room.maxPlayers,
        expectedSR: room.expectedSR,
        players: room.players,
        teamA: room.teamA,
        teamB: room.teamB,
        state: room.state,
        createdAt: room.createdAt,
        department: room.department || null,
        province: room.province || null,
        district: room.district || null,
        mapsUrl: room.mapsUrl || null,
        captainA: room.captainA || null,
        captainB: room.captainB || null,
        scoreA: room.scoreA !== undefined ? room.scoreA : null,
        scoreB: room.scoreB !== undefined ? room.scoreB : null,
        scoreApprovalState: room.scoreApprovalState,
        pendingScoreA: room.pendingScoreA !== undefined ? room.pendingScoreA : null,
        pendingScoreB: room.pendingScoreB !== undefined ? room.pendingScoreB : null
      });
      if (error) console.error('Supabase Error updating room:', error.message);
    } catch (err) {
      console.error('Supabase Error updating room:', err);
    }
  }

  private async syncMessageToSupabase(msg: any) {
    const supabase = getSupabase();
    if (!supabase) return;
    try {
      const { error } = await supabase.from('messages').upsert({
        id: msg.id,
        roomId: msg.roomId,
        userId: msg.userId,
        userName: msg.userName,
        text: msg.text,
        createdAt: msg.createdAt
      });
      if (error) console.error('Supabase Error inserting message:', error.message);
    } catch (err) {
      console.error('Supabase Error inserting message:', err);
    }
  }

  private async syncHistoryToSupabase(item: any) {
    const supabase = getSupabase();
    if (!supabase) return;
    try {
      const { error } = await supabase.from('history').upsert({
        id: item.id,
        userId: item.userId,
        roomId: item.roomId,
        title: item.title,
        date: item.date,
        pitchType: item.pitchType,
        scoreA: item.scoreA,
        scoreB: item.scoreB,
        teamA: item.teamA,
        teamB: item.teamB,
        result: item.result,
        srChange: item.srChange,
        timestamp: item.timestamp
      });
      if (error) console.error('Supabase Error inserting history:', error.message);
    } catch (err) {
      console.error('Supabase Error inserting history:', err);
    }
  }

  private async deleteRoomFromSupabase(roomId: string) {
    const supabase = getSupabase();
    if (!supabase) return;
    try {
      const { error: roomErr } = await supabase.from('rooms').delete().eq('id', roomId);
      if (roomErr) console.error('Supabase Error deleting room:', roomErr.message);

      const { error: msgErr } = await supabase.from('messages').delete().eq('roomId', roomId);
      if (msgErr) console.error('Supabase Error deleting messages of room:', msgErr.message);
    } catch (err) {
      console.error('Supabase Error deleting room:', err);
    }
  }
}

export const db = new Database();
