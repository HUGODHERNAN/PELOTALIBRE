import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Trophy, Users, ShieldCheck, MapPin, Activity, 
  Sparkles, TrendingUp, Zap, ArrowRight, LogIn, UserPlus, Menu, X 
} from 'lucide-react';

interface LandingPageProps {
  onNavigateToAuth: (isLogin: boolean) => void;
}

export default function LandingPage({ onNavigateToAuth }: LandingPageProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  // Mock balanced teams to display the "essence" of the app
  const mockTeamA = [
    { name: 'Carlos (Tú)', pos: 'DEF', sr: 1120, color: 'from-blue-500 to-cyan-500' },
    { name: 'Mateo (Bot)', pos: 'MID', sr: 950, color: 'from-yellow-500 to-amber-500' },
    { name: 'Gerson', pos: 'FWD', sr: 1050, color: 'from-red-500 to-rose-500' },
    { name: 'Eduardo', pos: 'GK', sr: 900, color: 'from-purple-500 to-indigo-500' },
  ];

  const mockTeamB = [
    { name: 'Diego', pos: 'MID', sr: 1100, color: 'from-yellow-500 to-amber-500' },
    { name: 'Luis', pos: 'DEF', sr: 1020, color: 'from-blue-500 to-cyan-500' },
    { name: 'Renzo (Bot)', pos: 'FWD', sr: 1000, color: 'from-red-500 to-rose-500' },
    { name: 'Santiago', pos: 'GK', sr: 920, color: 'from-purple-500 to-indigo-500' },
  ];

  return (
    <div className="min-h-screen bg-[#0B0F13] text-gray-100 flex flex-col font-sans selection:bg-green-500/30 selection:text-green-300" id="landing-page-root">
      
      {/* NAVBAR */}
      <nav className="sticky top-0 z-50 bg-[#0B0F13]/90 backdrop-blur-md border-b border-gray-900/80 px-4 py-3 sm:py-4 transition-all duration-300" id="landing-navbar">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          
          {/* Left: Logo */}
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} id="navbar-logo">
            <div className="p-2 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl text-black shadow-lg shadow-green-500/10">
              <Trophy className="w-5 h-5 font-black" />
            </div>
            <div className="flex flex-col">
              <span className="font-black tracking-tighter text-white text-sm sm:text-base leading-none uppercase italic">
                MATCHMAKER
              </span>
              <span className="text-[9px] text-green-400 font-mono tracking-widest uppercase font-bold leading-none mt-0.5">
                Fútbol Amateur
              </span>
            </div>
          </div>

          {/* Middle: Centered Slogan */}
          <div className="hidden md:flex items-center" id="navbar-slogan">
            <p className="text-xs uppercase font-extrabold tracking-widest text-gray-500 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-green-500" />
              <span>Equipos Balanceados. Pichangas Épicas.</span>
            </p>
          </div>

          {/* Right: Registration & Mobile Hamburger */}
          <div className="flex items-center gap-2.5">
            {/* Desktop Actions */}
            <div className="hidden md:flex items-center gap-2.5" id="navbar-actions">
              <button
                onClick={() => onNavigateToAuth(true)}
                className="text-xs text-gray-400 hover:text-white font-bold uppercase tracking-wider px-3 py-2 transition-colors flex items-center gap-1.5"
                id="nav-login-btn"
              >
                <LogIn className="w-3.5 h-3.5" />
                Ingresar
              </button>
              <button
                onClick={() => onNavigateToAuth(false)}
                className="px-4 py-2 bg-green-500 hover:bg-green-400 text-black font-black uppercase text-xs tracking-wider rounded-xl transition-all duration-200 shadow-md shadow-green-500/10 hover:shadow-green-500/20 italic flex items-center gap-1.5"
                id="nav-register-btn"
              >
                <UserPlus className="w-3.5 h-3.5 stroke-[3]" />
                Registrarse
              </button>
            </div>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-gray-400 hover:text-white hover:bg-gray-900 rounded-xl transition-all focus:outline-none"
              id="navbar-hamburger-btn"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6 text-green-500" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>

        {/* Mobile Menu Dropdown */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="md:hidden border-t border-gray-900/65 bg-[#0B0F13]/95 overflow-hidden"
              id="mobile-nav-menu"
            >
              <div className="px-4 py-5 space-y-4 flex flex-col">
                <a
                  href="#about-section"
                  onClick={(e) => {
                    e.preventDefault();
                    setMobileMenuOpen(false);
                    document.getElementById('about-section')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="text-xs uppercase font-extrabold tracking-widest text-gray-400 hover:text-white transition-colors py-2 border-b border-gray-900/40"
                >
                  ¿Quiénes Somos?
                </a>
                <a
                  href="#offers-section"
                  onClick={(e) => {
                    e.preventDefault();
                    setMobileMenuOpen(false);
                    document.getElementById('offers-section')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="text-xs uppercase font-extrabold tracking-widest text-gray-400 hover:text-white transition-colors py-2 border-b border-gray-900/40"
                >
                  ¿Qué Buscamos / Ofrecemos?
                </a>
                
                <div className="flex flex-col gap-2.5 pt-2">
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      onNavigateToAuth(true);
                    }}
                    className="w-full text-center text-xs text-gray-400 hover:text-white font-bold uppercase tracking-wider py-3 bg-gray-950 border border-gray-900 rounded-xl transition-colors flex items-center justify-center gap-1.5"
                    id="mobile-nav-login-btn"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    Ingresar
                  </button>
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      onNavigateToAuth(false);
                    }}
                    className="w-full px-4 py-3 bg-green-500 hover:bg-green-400 text-black font-black uppercase text-xs tracking-wider rounded-xl transition-all duration-200 shadow-md shadow-green-500/10 italic flex items-center justify-center gap-1.5"
                    id="mobile-nav-register-btn"
                  >
                    <UserPlus className="w-3.5 h-3.5 stroke-[3]" />
                    Registrarse
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* HERO SECTION */}
      <section className="relative pt-8 pb-16 sm:py-24 px-4 overflow-hidden border-b border-gray-950" id="landing-hero-section">
        {/* Subtle background glow effect */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-green-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
          
          {/* Left Text Column */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tighter leading-none uppercase italic" id="hero-title">
              Arma tu pichanga.<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500">
                Equilibra tus equipos.
              </span>
            </h1>

            <p className="text-gray-400 text-sm sm:text-base max-w-2xl mx-auto lg:mx-0 leading-relaxed font-medium">
              El motor inteligente de emparejamiento que calcula el nivel de cada jugador para garantizar partidos balanceados al milímetro en Lima y Arequipa.
            </p>

            <div className="flex flex-col gap-3 pt-4 max-w-sm mx-auto lg:mx-0">
              <button
                onClick={() => onNavigateToAuth(true)}
                className="w-full px-8 py-3.5 bg-gray-950 hover:bg-gray-900 border border-gray-800 hover:border-gray-750 text-white font-black uppercase text-xs sm:text-sm tracking-wide rounded-xl transition-all duration-200 flex items-center justify-center gap-2 italic"
                id="hero-cta-login-above"
              >
                <LogIn className="w-4 h-4 text-green-500" />
                Ingresar a Mi Cuenta
              </button>
              <div className="flex flex-col sm:flex-row gap-3 w-full">
                <button
                  onClick={() => onNavigateToAuth(false)}
                  className="w-full sm:w-auto px-8 py-4 bg-green-500 hover:bg-green-400 text-black font-black uppercase text-sm tracking-wide rounded-xl transition-all duration-200 shadow-xl shadow-green-500/15 hover:shadow-green-500/25 flex items-center justify-center gap-2 group italic"
                  id="hero-cta-register"
                >
                  Crear Mi Perfil Gratis
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </button>
                <button
                  onClick={() => {
                    const target = document.getElementById('about-section');
                    if (target) target.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="w-full sm:w-auto px-6 py-4 bg-gray-950 hover:bg-gray-900 border border-gray-800 hover:border-gray-700 text-white font-extrabold uppercase text-xs tracking-wider rounded-xl transition-colors flex items-center justify-center gap-1.5"
                  id="hero-cta-about"
                >
                  Conocer Más
                </button>
              </div>
            </div>
          </div>

          {/* Right Visual Matchmaking Preview Column */}
          <div className="lg:col-span-5 flex justify-center" id="hero-preview-container">
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="w-full max-w-sm bg-gray-950/60 border border-gray-800 rounded-3xl p-6 shadow-2xl relative"
            >
              {/* Green active element decoration */}
              <div className="absolute top-0 right-1/4 -translate-y-1/2 px-3 py-1 bg-green-500 text-black text-[9px] font-black uppercase tracking-widest rounded-full shadow-lg shadow-green-500/20 italic">
                SALA DE DEMOSTRACIÓN
              </div>

              <div className="flex items-center justify-between mb-4 border-b border-gray-900 pb-3">
                <div>
                  <h3 className="font-extrabold text-xs text-white uppercase tracking-wider flex items-center gap-1">
                    <Activity className="w-3.5 h-3.5 text-green-500" />
                    Pichanga de los Viernes
                  </h3>
                  <span className="text-[9px] text-gray-500 uppercase font-bold">Fútbol 7 (7v7) • Lima</span>
                </div>
                <div className="px-2.5 py-1 bg-green-500/10 border border-green-500/20 text-green-400 font-bold text-[9px] rounded-lg tracking-wider">
                  SR Prom: 1000
                </div>
              </div>

              {/* Matchmaking Field preview layout */}
              <div className="space-y-4">
                <div className="flex items-center justify-between bg-gray-900/40 p-2.5 rounded-xl border border-gray-900">
                  <div className="text-[10px] uppercase font-extrabold tracking-wider text-blue-400 flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-blue-500" />
                    Equipo Local (A)
                  </div>
                  <div className="text-[10px] font-mono text-gray-400">
                    Suma SR: <span className="font-bold text-white">4020</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  {mockTeamA.map((player, idx) => (
                    <div key={idx} className="flex items-center justify-between text-xs py-1.5 px-3 bg-gray-900/20 border border-gray-900/50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <span className="text-[8px] font-bold text-gray-500 font-mono w-4">#{idx+1}</span>
                        <span className="font-bold text-gray-300">{player.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-gray-950 border border-gray-800 text-gray-400">
                          {player.pos}
                        </span>
                        <span className="font-mono text-[10px] font-bold text-blue-400">
                          {player.sr} SR
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Verses divider indicator */}
                <div className="flex items-center justify-center gap-3 my-2">
                  <div className="h-px bg-gradient-to-r from-transparent to-gray-800 flex-1" />
                  <span className="text-[10px] font-black text-green-500 italic uppercase">VS</span>
                  <div className="h-px bg-gradient-to-l from-transparent to-gray-800 flex-1" />
                </div>

                <div className="flex items-center justify-between bg-gray-900/40 p-2.5 rounded-xl border border-gray-900">
                  <div className="text-[10px] uppercase font-extrabold tracking-wider text-rose-400 flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-rose-500" />
                    Equipo Visitante (B)
                  </div>
                  <div className="text-[10px] font-mono text-gray-400">
                    Suma SR: <span className="font-bold text-white">4040</span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  {mockTeamB.map((player, idx) => (
                    <div key={idx} className="flex items-center justify-between text-xs py-1.5 px-3 bg-gray-900/20 border border-gray-900/50 rounded-lg">
                      <div className="flex items-center gap-2">
                        <span className="text-[8px] font-bold text-gray-500 font-mono w-4">#{idx+5}</span>
                        <span className="font-bold text-gray-300">{player.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[8px] font-bold px-1.5 py-0.5 rounded bg-gray-950 border border-gray-800 text-gray-400">
                          {player.pos}
                        </span>
                        <span className="font-mono text-[10px] font-bold text-rose-400">
                          {player.sr} SR
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Matchmaking Confidence Level */}
                <div className="pt-3 border-t border-gray-900/80 flex items-center justify-between text-[10px] uppercase font-bold">
                  <span className="text-gray-500">Probabilidad de Victoria</span>
                  <span className="text-green-400 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    50% - 50% (PERFECTO)
                  </span>
                </div>
              </div>
            </motion.div>
          </div>

        </div>
      </section>

      {/* WHO WE ARE (QUIENES SOMOS) SECTION */}
      <section className="py-16 sm:py-24 bg-gray-950/40 border-b border-gray-950 px-4" id="about-section">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-green-500/10 border border-green-500/20 text-green-400 rounded-full text-[10px] font-bold tracking-widest uppercase mb-1">
            <Users className="w-3 h-3 text-green-500" />
            ¿Quiénes Somos?
          </div>

          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight uppercase italic leading-none">
            Futbolistas de Corazón,<br />
            <span className="text-green-400">Impulsados por la Tecnología.</span>
          </h2>

          <p className="text-gray-400 text-sm sm:text-base leading-relaxed font-medium">
            Somos un equipo de desarrolladores y amantes del fútbol amateur de Lima y Arequipa. 
            Estábamos cansados de las típicas "pichangas" frustrantes en las que un equipo terminaba goleando 12-1 al otro 
            porque los organizadores elegían a dedo a sus amigos. También odiábamos el caos de organizar los partidos por WhatsApp 
            con listas que cambiaban en el último minuto, la falta constante de un arquero comprometido, y la dificultad para encontrar canchas libres.
          </p>

          <p className="text-gray-400 text-sm sm:text-base leading-relaxed font-medium">
            Decidimos que cada partido amateur de fin de semana merece la emoción, la competitividad sana y la seriedad táctica 
            de una liga profesional. Con esa visión creamos Fútbol Matchmaker: un espacio justo, transparente y completamente automatizado 
            donde tu única preocupación sea sudar la camiseta y lucirte en el campo.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl mx-auto pt-6 text-left">
            <div className="p-4 bg-[#0B0F13] border border-gray-900 rounded-2xl flex items-start gap-3">
              <div className="p-2 bg-green-500/10 rounded-xl text-green-400 mt-1">
                <MapPin className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-white uppercase">Soporte Localizado</h4>
                <p className="text-xs text-gray-500 leading-normal mt-1">
                  Enfocados en los mejores complejos deportivos de Lima y Arequipa, con selección de distritos reales.
                </p>
              </div>
            </div>

            <div className="p-4 bg-[#0B0F13] border border-gray-900 rounded-2xl flex items-start gap-3">
              <div className="p-2 bg-green-500/10 rounded-xl text-green-400 mt-1">
                <Trophy className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-white uppercase">Pasión Competitiva</h4>
                <p className="text-xs text-gray-500 leading-normal mt-1">
                  Establecemos un Skill Rating (SR) transparente para cada jugador que se actualiza tras cada partido.
                </p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* WHAT WE SEEK & WHAT WE OFFER (BUSCAMOS / OFRECEMOS) SECTION */}
      <section className="py-16 sm:py-24 px-4 max-w-7xl mx-auto space-y-12" id="offers-section">
        
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-green-500/10 border border-green-500/20 text-green-400 rounded-full text-[10px] font-bold tracking-widest uppercase">
            <ShieldCheck className="w-3 h-3 text-green-500" />
            Nuestra Misión
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight uppercase italic">
            ¿Qué Buscamos y Qué Ofrecemos?
          </h2>
          <p className="text-gray-500 text-xs sm:text-sm max-w-xl mx-auto font-semibold uppercase tracking-wider">
            Transformando radicalmente la experiencia del fútbol amateur peruano.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          
          {/* Feature 1 */}
          <div className="p-6 bg-gray-950/40 border border-gray-850 hover:border-gray-800 rounded-2xl space-y-4 transition-all hover:translate-y-[-2px] flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 bg-blue-500/10 text-blue-400 rounded-xl flex items-center justify-center font-bold">
                <TrendingUp className="w-5 h-5" />
              </div>
              <h3 className="font-black text-lg text-white uppercase tracking-tight">
                Skill Rating Justo
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                <strong className="text-green-400 font-extrabold uppercase text-[10px] tracking-wide block mb-1">LO QUE BUSCAMOS:</strong>
                Erradicar los partidos desiguales y las goleadas aburridas que arruinan la diversión de todos en la cancha.
              </p>
              <p className="text-xs text-gray-400 leading-relaxed">
                <strong className="text-blue-400 font-extrabold uppercase text-[10px] tracking-wide block mb-1">LO QUE OFRECEMOS:</strong>
                Un motor matemático inteligente que asigna y recalcula tu SR dinámicamente según victorias, derrotas y nivel de los rivales.
              </p>
            </div>
          </div>

          {/* Feature 2 */}
          <div className="p-6 bg-gray-950/40 border border-gray-850 hover:border-gray-800 rounded-2xl space-y-4 transition-all hover:translate-y-[-2px] flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 bg-yellow-500/10 text-yellow-400 rounded-xl flex items-center justify-center font-bold">
                <Activity className="w-5 h-5" />
              </div>
              <h3 className="font-black text-lg text-white uppercase tracking-tight">
                Distribución Táctica
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                <strong className="text-green-400 font-extrabold uppercase text-[10px] tracking-wide block mb-1">LO QUE BUSCAMOS:</strong>
                Acabar con la anarquía táctica donde nadie quiere atajar o defender y todos se aglomeran en la delantera.
              </p>
              <p className="text-xs text-gray-400 leading-relaxed">
                <strong className="text-yellow-400 font-extrabold uppercase text-[10px] tracking-wide block mb-1">LO QUE OFRECEMOS:</strong>
                Registro y emparejamiento basado en tu posición favorita (Portero, Defensa, Medio, Delantero) para un balance de juego realista.
              </p>
            </div>
          </div>

          {/* Feature 3 */}
          <div className="p-6 bg-gray-950/40 border border-gray-850 hover:border-gray-800 rounded-2xl space-y-4 transition-all hover:translate-y-[-2px] flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 bg-green-500/10 text-green-400 rounded-xl flex items-center justify-center font-bold">
                <MapPin className="w-5 h-5" />
              </div>
              <h3 className="font-black text-lg text-white uppercase tracking-tight">
                Logística Detallada
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                <strong className="text-green-400 font-extrabold uppercase text-[10px] tracking-wide block mb-1">LO QUE BUSCAMOS:</strong>
                Evitar las confusiones del tipo "¿en qué cancha jugamos?", "¿cómo llego?" o "¿dónde queda el complejo deportivo?".
              </p>
              <p className="text-xs text-gray-400 leading-relaxed">
                <strong className="text-green-400 font-extrabold uppercase text-[10px] tracking-wide block mb-1">LO QUE OFRECEMOS:</strong>
                Geolocalización precisa de canchas en Lima y Arequipa con enlaces directos a Google Maps para navegación instantánea por GPS.
              </p>
            </div>
          </div>

          {/* Feature 4 */}
          <div className="p-6 bg-gray-950/40 border border-gray-850 hover:border-gray-800 rounded-2xl space-y-4 transition-all hover:translate-y-[-2px] flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 bg-purple-500/10 text-purple-400 rounded-xl flex items-center justify-center font-bold">
                <Sparkles className="w-5 h-5" />
              </div>
              <h3 className="font-black text-lg text-white uppercase tracking-tight">
                Bots de Relleno e Historial
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                <strong className="text-green-400 font-extrabold uppercase text-[10px] tracking-wide block mb-1">LO QUE BUSCAMOS:</strong>
                Eliminar el dolor de cabeza de los jugadores que faltan a última hora, dejando el partido incompleto.
              </p>
              <p className="text-xs text-gray-400 leading-relaxed">
                <strong className="text-purple-400 font-extrabold uppercase text-[10px] tracking-wide block mb-1">LO QUE OFRECEMOS:</strong>
                Autocompletado instantáneo con bots balanceados inteligentes para completar los cupos restantes y un historial completo de tu progreso.
              </p>
            </div>
          </div>

        </div>

        {/* BOTTOM CTA */}
        <div className="bg-gradient-to-br from-[#121921] to-[#0D131A] border border-gray-900 rounded-3xl p-8 sm:p-12 text-center space-y-6 relative overflow-hidden" id="bottom-cta-banner">
          <div className="absolute -top-12 -right-12 w-48 h-48 bg-green-500/5 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-green-500/5 rounded-full blur-2xl pointer-events-none" />

          <h3 className="text-2xl sm:text-3xl font-black text-white uppercase italic tracking-tight">
            ¿Listo para demostrar tu nivel en la cancha?
          </h3>
          <p className="text-gray-400 text-sm max-w-xl mx-auto leading-relaxed">
            Crea tu perfil en un minuto, elige tu ubicación de juego, ingresa tu posición favorita, y entra al lobby de la sala que prefieras para empezar a jugar partidos perfectamente parejos.
          </p>

          <div>
            <button
              onClick={() => onNavigateToAuth(false)}
              className="px-8 py-4 bg-green-500 hover:bg-green-400 text-black font-black uppercase text-sm tracking-wide rounded-xl transition-all duration-200 shadow-lg shadow-green-500/10 hover:shadow-green-500/25 inline-flex items-center gap-2 italic"
              id="bottom-cta-btn"
            >
              Registrarse Gratis Ahora
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </section>

      {/* FOOTER */}
      <footer className="mt-auto bg-gray-950/60 border-t border-gray-900/60 py-6 sm:py-8 px-4 text-center text-xs text-gray-500 font-medium" id="landing-footer">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© {new Date().getFullYear()} Fútbol Matchmaker Amateur. Todos los derechos reservados.</p>
          <p className="flex items-center gap-1">
            Diseñado con precisión para canchas de <strong className="text-gray-400">Lima</strong> y <strong className="text-gray-400">Arequipa</strong>.
          </p>
        </div>
      </footer>

    </div>
  );
}
