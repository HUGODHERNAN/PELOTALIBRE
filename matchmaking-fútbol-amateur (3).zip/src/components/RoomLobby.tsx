import React, { useState, useEffect, useRef } from 'react';
import { apiFetch, getSocket } from '../lib/api';
import { User, Room, Message, Position, PlayerInfo } from '../types';
import { 
  Users, MessageSquare, ArrowLeft, Play, ShieldCheck, 
  Send, UserMinus, Sparkles, HelpCircle, Trophy, Award, Scale, HelpCircle as HelpIcon, Calendar, Clock,
  Trash2, Cpu, MapPin
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface RoomLobbyProps {
  roomId: string;
  currentUser: User;
  onLeaveRoom: () => void;
}

export default function RoomLobby({ roomId, currentUser, onLeaveRoom }: RoomLobbyProps) {
  const [room, setRoom] = useState<Room | null>(null);
  const [playersDetailed, setPlayersDetailed] = useState<User[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Finish match modal state
  const [showFinishModal, setShowFinishModal] = useState(false);
  const [scoreA, setScoreA] = useState<number | ''>('');
  const [scoreB, setScoreB] = useState<number | ''>('');
  const [submittingResult, setSubmittingResult] = useState(false);
  const [finishError, setFinishError] = useState('');

  const [approvingResult, setApprovingResult] = useState(false);
  const [rejectingResult, setRejectingResult] = useState(false);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const socket = getSocket();

  // Scroll to bottom of chat
  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Fetch initial room details and messages
  const loadRoomAndMessages = async () => {
    try {
      let roomData = await apiFetch<Room & { playersDetailed: User[] }>(`/rooms/${roomId}`);
      
      // Auto-join if user is not in the players list and the room is in 'lobby' state
      if (roomData.state === 'lobby' && !roomData.players.includes(currentUser.id)) {
        roomData = await apiFetch<Room & { playersDetailed: User[] }>(`/rooms/${roomId}/join`, {
          method: 'POST',
        });
      }

      setRoom(roomData);
      setPlayersDetailed(roomData.playersDetailed || []);

      const msgs = await apiFetch<Message[]>(`/rooms/${roomId}/messages`);
      setMessages(msgs);
    } catch (err: any) {
      setError(err.message || 'Error al cargar la sala');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setLoading(true);
    loadRoomAndMessages();

    // Configure socket connection
    const handleJoinSocket = () => {
      socket.emit('join_room', { roomId });
    };

    if (socket.connected) {
      handleJoinSocket();
    } else {
      socket.connect();
      socket.on('connect', handleJoinSocket);
    }

    // Listen to real-time events
    socket.on('room_updated', (updatedRoom: Room & { playersDetailed?: User[] }) => {
      setRoom(updatedRoom);
      if (updatedRoom.playersDetailed) {
        setPlayersDetailed(updatedRoom.playersDetailed);
      }
    });

    socket.on('room_deleted', () => {
      alert('La sala ha sido eliminada por el organizador.');
      onLeaveRoom();
    });

    socket.on('chat_message', (message: Message) => {
      setMessages((prev) => {
        // Prevent duplicate append
        if (prev.some((m) => m.id === message.id)) return prev;
        return [...prev, message];
      });
    });

    return () => {
      socket.emit('leave_room', { roomId });
      socket.off('connect', handleJoinSocket);
      socket.off('room_updated');
      socket.off('room_deleted');
      socket.off('chat_message');
    };
  }, [roomId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !room) return;

    socket.emit('send_message', {
      roomId,
      userId: currentUser.id,
      userName: currentUser.name,
      text: chatInput.trim(),
    });

    setChatInput('');
  };

  const handleLeaveRoom = async () => {
    try {
      await apiFetch(`/rooms/${roomId}/leave`, { method: 'POST' });
      onLeaveRoom();
    } catch (err: any) {
      alert(err.message || 'Error al salir de la sala');
    }
  };

  const handleDeleteRoom = async () => {
    if (!window.confirm('¿Estás seguro de que deseas eliminar esta sala por completo? Todos los jugadores serán expulsados.')) {
      return;
    }
    try {
      await apiFetch(`/rooms/${roomId}/delete`, { method: 'POST' });
      onLeaveRoom();
    } catch (err: any) {
      alert(err.message || 'Error al eliminar la sala');
    }
  };

  const handleFillBots = async () => {
    try {
      await apiFetch(`/rooms/${roomId}/fill-bots`, { method: 'POST' });
    } catch (err: any) {
      alert(err.message || 'Error al llenar la sala con bots');
    }
  };

  const handleStartMatch = async () => {
    try {
      await apiFetch(`/rooms/${roomId}/start`, { method: 'POST' });
    } catch (err: any) {
      alert(err.message || 'Error al iniciar el partido');
    }
  };

  const handleFinishMatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (scoreA === '' || scoreB === '') {
      setFinishError('Por favor introduce un puntaje válido para ambos equipos.');
      return;
    }

    setFinishError('');
    setSubmittingResult(true);

    try {
      await apiFetch(`/rooms/${roomId}/finish`, {
        method: 'POST',
        body: JSON.stringify({
          scoreA: Number(scoreA),
          scoreB: Number(scoreB),
        }),
      });
      setShowFinishModal(false);
    } catch (err: any) {
      setFinishError(err.message || 'Error al finalizar el partido');
    } finally {
      setSubmittingResult(false);
    }
  };

  const handleApproveScore = async () => {
    setApprovingResult(true);
    try {
      await apiFetch(`/rooms/${roomId}/approve`, {
        method: 'POST',
      });
    } catch (err: any) {
      alert(err.message || 'Error al aprobar el resultado');
    } finally {
      setApprovingResult(false);
    }
  };

  const handleRejectScore = async () => {
    setRejectingResult(true);
    try {
      await apiFetch(`/rooms/${roomId}/reject`, {
        method: 'POST',
      });
    } catch (err: any) {
      alert(err.message || 'Error al rechazar el resultado');
    } finally {
      setRejectingResult(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center" id="room-loader">
        <div className="animate-spin w-10 h-10 border-4 border-emerald-600 border-t-transparent rounded-full mb-3" />
        <span className="text-sm font-bold text-slate-500">Conectando a la sala de juego en tiempo real...</span>
      </div>
    );
  }

  if (error || !room) {
    return (
      <div className="min-h-screen bg-slate-50 p-6 flex flex-col items-center justify-center" id="room-error">
        <div className="p-4 bg-rose-50 border border-rose-100 rounded-3xl text-rose-600 max-w-md text-center">
          <p className="font-bold text-lg mb-2">Error de conexión</p>
          <p className="text-sm">{error || 'La sala seleccionada no existe o fue eliminada.'}</p>
          <button 
            onClick={onLeaveRoom}
            className="mt-4 px-4 py-2 bg-rose-600 text-white font-bold rounded-xl text-xs hover:bg-rose-700 transition-colors inline-flex items-center"
          >
            <ArrowLeft className="w-4 h-4 mr-1" /> Volver al Dashboard
          </button>
        </div>
      </div>
    );
  }

  const isCreator = room.creatorId === currentUser.id;
  const isLobby = room.state === 'lobby';
  const isStarted = room.state === 'started';
  const isFinished = room.state === 'finished';

  // Helper to map a user ID to their detailed profile
  const getPlayerDetails = (id: string): User | undefined => {
    return playersDetailed.find((p) => p.id === id);
  };

  const teamAPlayers = room.teamA.map(getPlayerDetails).filter((p): p is User => p !== undefined);
  const teamBPlayers = room.teamB.map(getPlayerDetails).filter((p): p is User => p !== undefined);

  // Compute stats
  const avgSRA = teamAPlayers.length > 0
    ? Math.round(teamAPlayers.reduce((sum, p) => sum + p.skillRating, 0) / teamAPlayers.length)
    : 0;

  const avgSRB = teamBPlayers.length > 0
    ? Math.round(teamBPlayers.reduce((sum, p) => sum + p.skillRating, 0) / teamBPlayers.length)
    : 0;

  const srDiff = Math.abs(avgSRA - avgSRB);
  const isVeryBalanced = srDiff <= 60 && teamAPlayers.length > 0 && teamBPlayers.length > 0;

  const creatorTeam = room.teamA.includes(room.creatorId) ? 'A' : (room.teamB.includes(room.creatorId) ? 'B' : null);
  const otherCaptainId = creatorTeam === 'A' ? room.captainB : (creatorTeam === 'B' ? room.captainA : null);
  const otherCaptain = otherCaptainId ? getPlayerDetails(otherCaptainId) : undefined;
  const isOpposingCaptain = currentUser.id === otherCaptainId;

  const isTeamA = room.teamA.includes(currentUser.id);
  const isTeamB = room.teamB.includes(currentUser.id);

  const isCaptainA = room.captainA === currentUser.id;
  const isCaptainB = room.captainB === currentUser.id;
  const isAnyCaptain = isCaptainA || isCaptainB;

  const myTeamApproved = isTeamB ? room.captainBApproved : room.captainAApproved;
  const opposingTeamApproved = isTeamB ? room.captainAApproved : room.captainBApproved;

  const teamCapID = isTeamB ? room.captainB : room.captainA;
  const hasHumanCaptainOnMyTeam = teamCapID && !teamCapID.startsWith('bot_');
  const canIApprove = !myTeamApproved && (isAnyCaptain || (!hasHumanCaptainOnMyTeam && (isTeamA || isTeamB)));

  const positionColors: Record<Position, string> = {
    GK: 'bg-amber-500/10 border-amber-500/20 text-amber-400',
    DEF: 'bg-blue-500/10 border-blue-500/20 text-blue-400',
    MID: 'bg-emerald-500/10 border-emerald-500/20 text-green-400',
    FWD: 'bg-rose-500/10 border-rose-500/20 text-rose-400'
  };

  return (
    <div className="min-h-screen bg-[#0B0F13] text-gray-100 font-sans flex flex-col" id="lobby-layout">
      
      {/* ROOM NAVBAR HEADER */}
      <header className="bg-[#151B22] border-b border-gray-800/80 py-4 px-4 sm:px-6 lg:px-8" id="lobby-navbar">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center space-x-3">
            <button
              onClick={onLeaveRoom}
              className="p-2.5 bg-gray-950 hover:bg-gray-800 text-gray-400 hover:text-white rounded-xl transition-colors border border-gray-800"
              id="back-to-dashboard-btn"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="font-black font-display text-white text-lg sm:text-xl truncate max-w-sm uppercase italic tracking-tight">
                  {room.title}
                </h2>
                <span className="text-[9px] px-2.5 py-0.5 font-black uppercase tracking-wider rounded bg-green-500/10 border border-green-500/30 text-green-400">
                  Cancha {room.pitchType}
                </span>
              </div>
              <p className="text-[10px] text-gray-500 uppercase font-bold mt-0.5 tracking-wider">
                Organizador: <strong className="text-gray-300 font-extrabold">{room.creatorName}</strong>
              </p>

              {/* Ubicación y enlace a Google Maps */}
              {room.department && (
                <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2 mt-1.5 text-xs text-gray-400">
                  <div className="flex items-center font-bold uppercase text-[10px] text-green-400 tracking-wider">
                    <MapPin className="w-3.5 h-3.5 mr-1 text-green-500 shrink-0" />
                    <span>{room.department} • {room.province} • {room.district}</span>
                  </div>
                  {room.mapsUrl && (
                    <a
                      href={room.mapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-green-400 hover:text-green-300 transition-colors text-[10px] font-bold underline flex items-center gap-1"
                      id="lobby-maps-link"
                    >
                      Ver en Google Maps ↗
                    </a>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-2 shrink-0 w-full sm:w-auto justify-end">
            {isLobby && (
              <button
                onClick={handleLeaveRoom}
                className="px-4 py-2 bg-gray-950 text-rose-400 hover:bg-rose-950/20 border border-gray-800 hover:border-rose-900/40 rounded-xl font-bold text-xs transition-all flex items-center shadow-md uppercase tracking-wider"
                id="leave-room-btn"
              >
                <UserMinus className="w-4 h-4 mr-1.5" />
                Salir de Sala
              </button>
            )}

            {isCreator && isLobby && (
              <button
                onClick={handleDeleteRoom}
                className="px-4 py-2 bg-gray-950 text-red-500 hover:bg-red-950/20 border border-gray-800 hover:border-red-900/40 rounded-xl font-bold text-xs transition-all flex items-center shadow-md uppercase tracking-wider"
                id="delete-room-btn"
              >
                <Trash2 className="w-4 h-4 mr-1.5" />
                Eliminar Sala
              </button>
            )}

            {isCreator && isLobby && (
              <button
                onClick={handleFillBots}
                disabled={room.players.length >= room.maxPlayers}
                className="px-4 py-2 bg-[#1C2430] hover:bg-amber-500/10 text-amber-400 border border-amber-500/20 disabled:border-gray-800 disabled:text-gray-600 disabled:bg-gray-950 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl font-bold text-xs transition-all flex items-center shadow-md uppercase tracking-wider"
                id="fill-bots-btn"
              >
                <Cpu className="w-4 h-4 mr-1.5" />
                Llenar con Bots
              </button>
            )}

            {isCreator && isLobby && (
              <button
                onClick={handleStartMatch}
                disabled={room.players.length < 2}
                className="px-5 py-2.5 bg-green-500 hover:bg-green-400 disabled:bg-gray-950 disabled:border-gray-900 disabled:text-gray-700 text-black font-black uppercase italic rounded-xl text-xs transition-all flex items-center shadow-lg shadow-green-500/20"
                id="start-match-btn"
              >
                <Play className="w-4 h-4 mr-1.5" />
                Comenzar Partido
              </button>
            )}

            {(isAnyCaptain || isCreator) && isStarted && room.scoreApprovalState !== 'pending_approval' && (
              <button
                onClick={() => setShowFinishModal(true)}
                className="px-5 py-2.5 bg-green-500 hover:bg-green-400 text-black font-black uppercase italic rounded-xl text-xs transition-all flex items-center shadow-lg shadow-green-500/20"
                id="finish-match-trigger"
              >
                <Trophy className="w-4 h-4 mr-1.5 text-black" />
                Registrar Resultado
              </button>
            )}
          </div>
        </div>
      </header>

      {/* LOBBY GRID INTERACTION AREA */}
      <div className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* TEAM BALANCER & STAGE VIEW (3/4 grid width) */}
        <div className="lg:col-span-3 space-y-6 flex flex-col justify-between">
          
          {/* Real-time Matchmaking Status Header */}
          <div className="bg-[#151B22] rounded-3xl p-5 border border-gray-800 shadow-2xl">
              <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3">
                <div>
                  <span className="text-[9px] uppercase font-bold text-gray-500 tracking-widest">
                    Estado del Matchmaking
                  </span>
                  <h3 className="font-black text-white text-md mt-0.5 flex items-center uppercase italic tracking-tight">
                    {isLobby ? (
                      <>
                        <span className="inline-block w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse mr-2" />
                        Convocando Jugadores... ({room.players.length} de {room.maxPlayers})
                      </>
                    ) : isStarted ? (
                      <>
                        <span className={`inline-block w-2.5 h-2.5 rounded-full ${room.scoreApprovalState === 'pending_approval' ? 'bg-amber-500 animate-bounce' : 'bg-blue-500 animate-pulse'} mr-2`} />
                        {room.scoreApprovalState === 'pending_approval' ? `Esperando Confirmación (${room.pendingScoreA} - ${room.pendingScoreB})` : 'Partido Iniciado'}
                      </>
                    ) : (
                      <>
                        <span className="inline-block w-2.5 h-2.5 rounded-full bg-gray-500 mr-2" />
                        Partido Finalizado ({room.scoreA} - {room.scoreB})
                      </>
                    )}
                  </h3>
                </div>

              {/* Balance Badge Indicator */}
              {isLobby && (
                <div className="shrink-0 flex items-center space-x-2">
                  <div className="p-1.5 bg-gray-950 border border-gray-800 rounded-xl text-gray-400">
                    <Scale className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[8px] font-bold text-gray-500 uppercase tracking-wider block">Balance de SR</span>
                    <span className="text-xs font-black text-white font-mono block">
                      Dif: {srDiff} pts
                    </span>
                  </div>
                  {isVeryBalanced && (
                    <span className="text-[9px] font-black uppercase px-2.5 py-0.5 bg-green-500/10 text-green-400 border border-green-500/30 rounded-full flex items-center">
                      <Sparkles className="w-3.5 h-3.5 mr-1" /> Muy Equilibrado
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* If there are fewer than 2 players, show warning */}
            {isLobby && room.players.length < 2 && (
              <div className="mt-4 p-3.5 bg-amber-500/5 border border-amber-500/20 rounded-2xl text-amber-400 text-xs font-semibold flex items-center uppercase tracking-wider" id="lobby-warning">
                <HelpIcon className="w-4 h-4 mr-2 shrink-0 text-amber-500" />
                <span>Invita a más jugadores. Se necesitan al menos 2 jugadores para equilibrar los equipos.</span>
              </div>
            )}

            {/* SCORE PROPOSAL APPROVAL ALERT BANNER */}
            {isStarted && room.scoreApprovalState === 'pending_approval' && (
              <div className="mt-4 p-5 bg-[#1C232B] border border-amber-500/30 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-lg shadow-amber-500/5">
                <div className="flex items-start space-x-3 w-full">
                  <div className="p-2 bg-amber-500/10 text-amber-400 rounded-xl mt-1 shrink-0">
                    <Trophy className="w-5 h-5 text-amber-400 animate-pulse" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-extrabold text-white text-sm uppercase tracking-tight italic">
                      Confirmación de Resultado Propuesto: <span className="text-amber-400 font-mono text-base font-black ml-1">{room.pendingScoreA} - {room.pendingScoreB}</span>
                    </h4>
                    
                    {/* Explicit approvals tracker */}
                    <div className="mt-2.5 flex flex-wrap gap-4 text-xs font-bold uppercase tracking-wider">
                      <div className="flex items-center space-x-1.5">
                        <span className="text-gray-400">Equipo Local:</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${room.captainAApproved ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'}`}>
                          {room.captainAApproved ? '✅ Aceptado' : '⏳ Pendiente'}
                        </span>
                      </div>
                      <div className="flex items-center space-x-1.5">
                        <span className="text-gray-400">Equipo Visitante:</span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${room.captainBApproved ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'}`}>
                          {room.captainBApproved ? '✅ Aceptado' : '⏳ Pendiente'}
                        </span>
                      </div>
                    </div>

                    <p className="text-[11px] text-gray-400 mt-2.5 uppercase font-bold leading-relaxed">
                      {canIApprove ? (
                        <span className="text-amber-400">⚠️ ¡Tu equipo aún no ha aprobado este resultado! Por favor, confírmalo si el marcador es correcto, o recházalo para proponer uno nuevo.</span>
                      ) : myTeamApproved && !opposingTeamApproved ? (
                        <span>Tu equipo ya aprobó este resultado. Esperando que el capitán del equipo contrario ({otherCaptain?.name || 'Capitán contrario'}) acepte y confirme el resultado para actualizar los SRs.</span>
                      ) : (
                        <span>Esperando que ambos capitanes aprueben y confirmen el resultado propuesto para finalizar el partido de forma oficial.</span>
                      )}
                    </p>
                  </div>
                </div>

                <div className="flex items-center space-x-2 shrink-0 w-full md:w-auto justify-end">
                  {canIApprove && (
                    <>
                      <button
                        onClick={handleRejectScore}
                        disabled={rejectingResult || approvingResult}
                        className="px-4 py-2 bg-rose-950/40 text-rose-400 border border-rose-900/40 hover:bg-rose-900/30 rounded-xl font-black text-xs transition-all uppercase tracking-wider"
                        id="reject-score-btn"
                      >
                        {rejectingResult ? 'Rechazando...' : 'Rechazar'}
                      </button>
                      <button
                        onClick={handleApproveScore}
                        disabled={rejectingResult || approvingResult}
                        className="px-5 py-2.5 bg-green-500 hover:bg-green-400 text-black rounded-xl font-black text-xs transition-all uppercase tracking-wider shadow-lg shadow-green-500/20"
                        id="approve-score-btn"
                      >
                        {approvingResult ? 'Confirmando...' : 'Aceptar Resultado'}
                      </button>
                    </>
                  )}

                  {!canIApprove && (isCreator || isAnyCaptain) && (
                    <button
                      onClick={handleRejectScore}
                      disabled={rejectingResult}
                      className="px-4 py-2 bg-gray-950 text-gray-400 border border-gray-800 hover:bg-gray-800 rounded-xl font-black text-xs transition-all uppercase tracking-wider"
                      id="cancel-score-btn"
                    >
                      {rejectingResult ? 'Cancelando...' : 'Rechazar/Cancelar'}
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* TEAMS GRID PANEL */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch" id="teams-grid">
            
            {/* TEAM A - LOCAL (GRADIENT VIBE) */}
            <div className="bg-[#151B22] rounded-3xl p-6 border border-gray-800 shadow-2xl flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-center pb-4 border-b border-gray-800/80 mb-5">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-green-500" />
                    <h4 className="font-black text-white uppercase italic tracking-tight text-base">Equipo A (Local)</h4>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] text-gray-500 font-bold block uppercase">Promedio SR</span>
                    <strong className="text-sm font-black font-mono text-green-400">{avgSRA} SR</strong>
                  </div>
                </div>

                {teamAPlayers.length === 0 ? (
                  <div className="py-12 text-center text-gray-500 border border-dashed border-gray-800 rounded-2xl flex flex-col items-center uppercase font-bold tracking-wider">
                    <Users className="w-8 h-8 mb-2 text-gray-700" />
                    <span className="text-[10px]">Esperando jugadores...</span>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {teamAPlayers.map((player) => (
                      <motion.div
                        layoutId={`player-card-${player.id}`}
                        key={player.id}
                        className="p-3 bg-gray-950/40 border border-gray-800/40 rounded-2xl flex items-center justify-between"
                      >
                        <div className="flex items-center space-x-3 min-w-0">
                          <div className="w-9 h-9 rounded-xl bg-gray-800 text-white font-extrabold text-xs flex items-center justify-center shrink-0 uppercase">
                            {player.name.slice(0, 2)}
                          </div>
                          <div className="min-w-0">
                            <span className="font-extrabold text-sm text-white block truncate leading-tight uppercase tracking-tight">
                              {player.name}
                            </span>
                            <div className="flex items-center space-x-1.5 mt-0.5">
                              <span className="text-[8px] text-gray-500 font-mono block uppercase font-bold tracking-wider">
                                {player.id === room.creatorId ? 'Líder de Sala' : 'Jugador'}
                              </span>
                              {room.captainA === player.id && (
                                <span className="text-[8px] px-1 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded font-black uppercase tracking-wider scale-90 origin-left shrink-0">
                                  Capitán
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2 shrink-0">
                          <span className={`text-[9px] px-2 py-0.5 rounded font-black uppercase tracking-wider border ${positionColors[player.preferredPosition]}`}>
                            {player.preferredPosition}
                          </span>
                          <span className="text-xs font-black font-mono text-gray-300">
                            {player.skillRating}
                          </span>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>

              <div className="mt-6 pt-4 border-t border-gray-800/60 flex justify-between text-[10px] text-gray-500 uppercase font-bold">
                <span>Total Jugadores: <strong className="text-white">{teamAPlayers.length}</strong></span>
              </div>
            </div>

            {/* TEAM B - VISITANTE (SLATE VIBE) */}
            <div className="bg-[#151B22] rounded-3xl p-6 border border-gray-800 shadow-2xl flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-center pb-4 border-b border-gray-800/80 mb-5">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-blue-500" />
                    <h4 className="font-black text-white uppercase italic tracking-tight text-base">Equipo B (Visitante)</h4>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] text-gray-500 font-bold block uppercase">Promedio SR</span>
                    <strong className="text-sm font-black font-mono text-blue-400">{avgSRB} SR</strong>
                  </div>
                </div>

                {teamBPlayers.length === 0 ? (
                  <div className="py-12 text-center text-gray-500 border border-dashed border-gray-800 rounded-2xl flex flex-col items-center uppercase font-bold tracking-wider">
                    <Users className="w-8 h-8 mb-2 text-gray-700" />
                    <span className="text-[10px]">Esperando jugadores...</span>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {teamBPlayers.map((player) => (
                      <motion.div
                        layoutId={`player-card-${player.id}`}
                        key={player.id}
                        className="p-3 bg-gray-950/40 border border-gray-800/40 rounded-2xl flex items-center justify-between"
                      >
                        <div className="flex items-center space-x-3 min-w-0">
                          <div className="w-9 h-9 rounded-xl bg-gray-800 text-white font-extrabold text-xs flex items-center justify-center shrink-0 uppercase">
                            {player.name.slice(0, 2)}
                          </div>
                          <div className="min-w-0">
                            <span className="font-extrabold text-sm text-white block truncate leading-tight uppercase tracking-tight">
                              {player.name}
                            </span>
                            <div className="flex items-center space-x-1.5 mt-0.5">
                              <span className="text-[8px] text-gray-500 font-mono block uppercase font-bold tracking-wider">
                                {player.id === room.creatorId ? 'Líder de Sala' : 'Jugador'}
                              </span>
                              {room.captainB === player.id && (
                                <span className="text-[8px] px-1 bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded font-black uppercase tracking-wider scale-90 origin-left shrink-0">
                                  Capitán
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center space-x-2 shrink-0">
                          <span className={`text-[9px] px-2 py-0.5 rounded font-black uppercase tracking-wider border ${positionColors[player.preferredPosition]}`}>
                            {player.preferredPosition}
                          </span>
                          <span className="text-xs font-black font-mono text-gray-300">
                            {player.skillRating}
                          </span>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>

              <div className="mt-6 pt-4 border-t border-gray-800/60 flex justify-between text-[10px] text-gray-500 uppercase font-bold">
                <span>Total Jugadores: <strong className="text-white">{teamBPlayers.length}</strong></span>
              </div>
            </div>

          </div>

          {/* DYNAMIC FIELD ALIGNMENT PREVIEW CHART */}
          <div className="bg-slate-950 rounded-3xl p-6 border border-gray-800 relative overflow-hidden h-64 shadow-xl">
            {/* Soccer Field markings */}
            <div className="absolute inset-4 border border-white/5 rounded-2xl pointer-events-none">
              <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-[1px] bg-white/5" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 border border-white/5 rounded-full" />
              {/* Goal Area Left */}
              <div className="absolute top-1/2 -translate-y-1/2 left-0 w-12 h-28 border border-white/5" />
              {/* Goal Area Right */}
              <div className="absolute top-1/2 -translate-y-1/2 right-0 w-12 h-28 border border-white/5" />
            </div>

            <div className="absolute inset-0 flex justify-between px-10 py-6 text-white z-10">
              {/* Field Column Left: Team A lineup visualization */}
              <div className="w-1/2 h-full flex flex-col justify-around items-start">
                <div className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">Alineación Local (A)</div>
                <div className="flex flex-wrap gap-2 pr-4">
                  {teamAPlayers.map((player) => (
                    <span 
                      key={player.id} 
                      className="px-2 py-1 bg-green-500/10 border border-green-500/20 text-[10px] rounded-lg font-bold font-mono text-green-400"
                    >
                      {player.name.split(' ')[0]} ({player.preferredPosition})
                    </span>
                  ))}
                  {teamAPlayers.length === 0 && <span className="text-xs text-gray-600 font-bold uppercase">Sin jugadores</span>}
                </div>
              </div>

              {/* Field Column Right: Team B lineup visualization */}
              <div className="w-1/2 h-full flex flex-col justify-around items-end text-right">
                <div className="text-[10px] font-bold text-blue-400 uppercase tracking-wider">Alineación Visitante (B)</div>
                <div className="flex flex-wrap gap-2 pl-4 justify-end">
                  {teamBPlayers.map((player) => (
                    <span 
                      key={player.id} 
                      className="px-2 py-1 bg-blue-500/10 border border-blue-500/20 text-[10px] rounded-lg font-bold font-mono text-blue-300"
                    >
                      {player.name.split(' ')[0]} ({player.preferredPosition})
                    </span>
                  ))}
                  {teamBPlayers.length === 0 && <span className="text-xs text-gray-600 font-bold uppercase">Sin jugadores</span>}
                </div>
              </div>
            </div>
          </div>

        </div>

        {/* REAL-TIME CHAT SIDEBAR (1/4 grid width) */}
        <div className="lg:col-span-1 bg-[#151B22] rounded-3xl border border-gray-800 shadow-2xl flex flex-col h-[550px] overflow-hidden" id="chat-sidebar">
          
          {/* Chat Header */}
          <div className="p-4 border-b border-gray-800/80 flex items-center justify-between bg-gray-950/30 shrink-0">
            <div className="flex items-center space-x-2">
              <div className="p-1.5 bg-green-500/10 text-green-400 rounded-lg">
                <MessageSquare className="w-4 h-4" />
              </div>
              <span className="font-black text-xs text-gray-300 uppercase tracking-wider italic">
                Estrategia y Banter
              </span>
            </div>
            <span className="text-[9px] font-black text-green-400 uppercase font-mono">
              En Vivo
            </span>
          </div>

          {/* Chat Feed */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3.5 custom-scrollbar bg-gray-950/20">
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-gray-500 p-4">
                <MessageSquare className="w-8 h-8 mb-2 text-gray-800" />
                <p className="text-xs font-bold uppercase tracking-wider">Sin mensajes todavía</p>
                <p className="text-[9px] text-gray-600 mt-1 uppercase font-semibold leading-tight">Coordina el partido en tiempo real.</p>
              </div>
            ) : (
              messages.map((msg) => {
                const isMe = msg.userId === currentUser.id;
                return (
                  <div 
                    key={msg.id} 
                    className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                  >
                    <span className="text-[9px] text-gray-500 font-black uppercase mb-0.5 px-1 tracking-wider">
                      {isMe ? 'Tú' : msg.userName}
                    </span>
                    <div className={`p-2.5 rounded-2xl text-xs max-w-[95%] break-words ${
                      isMe 
                        ? 'bg-green-500/10 border border-green-500/20 text-white rounded-br-none' 
                        : 'bg-gray-950 border border-gray-800 text-gray-300 rounded-bl-none'
                    }`}>
                      {msg.text}
                    </div>
                  </div>
                );
              })
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Chat Input form */}
          {!isFinished ? (
            <form onSubmit={handleSendMessage} className="p-3 border-t border-gray-800 bg-gray-950/30 flex gap-2 shrink-0">
              <input
                type="text"
                placeholder="Escribe un mensaje..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                className="flex-1 bg-gray-950 border border-gray-800 rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 text-white placeholder-gray-600"
                id="chat-input"
              />
              <button
                type="submit"
                className="p-2 bg-green-500 hover:bg-green-400 text-black rounded-xl transition-colors shadow-lg"
                id="send-chat-btn"
              >
                <Send className="w-3.5 h-3.5 text-black" />
              </button>
            </form>
          ) : (
            <div className="p-4 border-t border-gray-800 bg-gray-950/50 text-center text-[10px] text-gray-500 uppercase font-black tracking-widest shrink-0">
              El chat está cerrado para partidos finalizados
            </div>
          )}

        </div>

      </div>

      {/* --- FINISH MATCH MODAL (HOSTS SCORE REPORT) --- */}
      <AnimatePresence>
        {showFinishModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" id="finish-modal-backdrop">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-[#151B22] rounded-3xl max-w-sm w-full shadow-2xl border border-gray-800 overflow-hidden relative z-50 text-white"
              id="finish-match-modal"
            >
              <div className="bg-gradient-to-r from-green-600 to-emerald-700 px-6 py-4 flex justify-between items-center text-white border-b border-gray-800">
                <div className="flex items-center space-x-2">
                  <Trophy className="w-5 h-5 text-green-200" />
                  <h3 className="font-extrabold font-display text-base">Registrar Resultado</h3>
                </div>
                <button 
                  onClick={() => setShowFinishModal(false)}
                  className="text-white/80 hover:text-white p-1 hover:bg-white/10 rounded-lg transition-colors"
                  id="close-finish-modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {finishError && (
                <div className="p-4 bg-rose-500/10 border-b border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center">
                  <ShieldCheck className="w-4 h-4 mr-2 text-rose-500" />
                  <span>{finishError}</span>
                </div>
              )}

              <form onSubmit={handleFinishMatch} className="p-6 space-y-5" id="finish-match-form">
                <p className="text-gray-400 text-xs leading-relaxed text-center uppercase font-semibold">
                  Ingresa los goles del partido. Esto reajustará el SR (Skill Rating) de todos los jugadores de forma justa según el balance.
                </p>

                <div className="grid grid-cols-2 gap-4 items-center text-center">
                  {/* Team A score */}
                  <div className="space-y-1.5 p-3 bg-gray-950 rounded-2xl border border-gray-800">
                    <span className="text-[9px] font-black text-green-400 uppercase block tracking-wider">Equipo A</span>
                    <input
                      type="number"
                      required
                      min="0"
                      value={scoreA}
                      onChange={(e) => setScoreA(e.target.value === '' ? '' : Number(e.target.value))}
                      placeholder="0"
                      className="w-full text-center text-3xl font-black font-mono bg-gray-950 text-white rounded-xl py-2 focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500"
                      id="score-a-input"
                    />
                  </div>

                  {/* Team B score */}
                  <div className="space-y-1.5 p-3 bg-gray-950 rounded-2xl border border-gray-800">
                    <span className="text-[9px] font-black text-blue-400 uppercase block tracking-wider">Equipo B</span>
                    <input
                      type="number"
                      required
                      min="0"
                      value={scoreB}
                      onChange={(e) => setScoreB(e.target.value === '' ? '' : Number(e.target.value))}
                      placeholder="0"
                      className="w-full text-center text-3xl font-black font-mono bg-gray-950 text-white rounded-xl py-2 focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500"
                      id="score-b-input"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={submittingResult}
                  className="w-full py-3.5 bg-green-500 hover:bg-green-400 text-black font-black uppercase tracking-tighter transition-colors rounded-xl shadow-lg shadow-green-500/20 italic text-sm flex items-center justify-center disabled:opacity-50"
                  id="submit-score-btn"
                >
                  {submittingResult ? 'PROCESANDO SR...' : 'GUARDAR Y FINALIZAR'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}

// Simple absolute close SVG
function X({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
  );
}
