import React, { useState, useEffect } from 'react';
import { apiFetch, removeToken } from '../lib/api';
import { User, Room, MatchHistoryItem, PitchType, Position } from '../types';
import { 
  Trophy, Users, Calendar, Clock, LogOut, Plus, 
  Search, ShieldAlert, Sparkles, Filter, Settings, 
  MapPin, CheckCircle2, Award, ChevronRight, RefreshCw, X,
  Brain, TrendingUp, Dumbbell, Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PERU_LOCATIONS } from '../lib/locations';

interface DashboardProps {
  user: User;
  onLogout: () => void;
  onJoinRoom: (roomId: string) => void;
  onUpdateUser: (updatedUser: User) => void;
}

export default function Dashboard({ user, onLogout, onJoinRoom, onUpdateUser }: DashboardProps) {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [history, setHistory] = useState<MatchHistoryItem[]>([]);
  const [loadingRooms, setLoadingRooms] = useState(true);
  const [loadingHistory, setLoadingHistory] = useState(true);
  const [filterPitch, setFilterPitch] = useState<string>('Todos');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Modals
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);

  // Supabase Status State
  const [supabaseStatus, setSupabaseStatus] = useState<{
    connection: boolean;
    reason: string;
    tables: { users: boolean; rooms: boolean; messages: boolean; history: boolean };
    url: string;
    key: string;
    sql: string;
  } | null>(null);
  const [showSupabaseModal, setShowSupabaseModal] = useState(false);
  const [loadingSupabase, setLoadingSupabase] = useState(false);
  
  // Create Room Form State
  const [createTitle, setCreateTitle] = useState('');
  const [createDate, setCreateDate] = useState('');
  const [createTime, setCreateTime] = useState('');
  const [createPitchType, setCreatePitchType] = useState<PitchType>('7v7');
  const [createMaxPlayers, setCreateMaxPlayers] = useState(14);
  const [createExpectedSR, setCreateExpectedSR] = useState(1000);
  const [createDept, setCreateDept] = useState('');
  const [createProv, setCreateProv] = useState('');
  const [createDist, setCreateDist] = useState('');
  const [createMapsUrl, setCreateMapsUrl] = useState('');
  const [createError, setCreateError] = useState('');
  const [creating, setCreating] = useState(false);

  // Profile Edit Form State
  const [profileName, setProfileName] = useState(user.name);
  const [profilePosition, setProfilePosition] = useState<Position>(user.preferredPosition);
  const [profileDept, setProfileDept] = useState(user.department || '');
  const [profileProv, setProfileProv] = useState(user.province || '');
  const [profileDist, setProfileDist] = useState(user.district || '');
  const [profileError, setProfileError] = useState('');
  const [updatingProfile, setUpdatingProfile] = useState(false);

  // Synchronize profile states when modal is opened or user changes
  useEffect(() => {
    if (showProfileModal) {
      setProfileName(user.name);
      setProfilePosition(user.preferredPosition);
      setProfileDept(user.department || '');
      setProfileProv(user.province || '');
      setProfileDist(user.district || '');
    }
  }, [showProfileModal, user]);

  // Synchronize create room states with user's locations when modal is opened
  useEffect(() => {
    if (showCreateModal) {
      setCreateDept(user.department || '');
      setCreateProv(user.province || '');
      setCreateDist(user.district || '');
    }
  }, [showCreateModal, user]);

  // Derived locations list for Create Room form
  const createDeptData = PERU_LOCATIONS.find(d => d.name === createDept);
  const createProvincesList = createDeptData ? createDeptData.provinces : [];
  const createProvData = createProvincesList.find(p => p.name === createProv);
  const createDistrictsList = createProvData ? createProvData.districts : [];

  // Get today's date in YYYY-MM-DD format (local time zone)
  const getTodayString = () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };
  const todayStr = getTodayString();

  // Derived locations list for Edit Profile form
  const profileDeptData = PERU_LOCATIONS.find(d => d.name === profileDept);
  const profileProvincesList = profileDeptData ? profileDeptData.provinces : [];
  const profileProvData = profileProvincesList.find(p => p.name === profileProv);
  const profileDistrictsList = profileProvData ? profileProvData.districts : [];

  // Fetch Rooms
  const fetchRooms = async () => {
    setLoadingRooms(true);
    try {
      const data = await apiFetch<Room[]>('/rooms');
      setRooms(data);
    } catch (err) {
      console.error('Error fetching rooms:', err);
    } finally {
      setLoadingRooms(false);
    }
  };

  // Fetch Match History
  const fetchHistory = async () => {
    setLoadingHistory(true);
    try {
      const data = await apiFetch<MatchHistoryItem[]>('/history');
      setHistory(data);
    } catch (err) {
      console.error('Error fetching history:', err);
    } finally {
      setLoadingHistory(false);
    }
  };

  // AI Coach state and fetching logic
  interface AICoachData {
    source: string;
    playstyleBadge: string;
    tacticalSummary: string;
    strengths: string[];
    weaknesses: string[];
    tips: string[];
    drills: { name: string; description: string; duration: string }[];
  }
  const [aiCoach, setAiCoach] = useState<AICoachData | null>(null);
  const [loadingAiCoach, setLoadingAiCoach] = useState(false);
  const [aiCoachError, setAiCoachError] = useState('');

  const fetchAiCoach = async () => {
    setLoadingAiCoach(true);
    setAiCoachError('');
    try {
      const data = await apiFetch<AICoachData>('/ai-coach');
      setAiCoach(data);
    } catch (err: any) {
      console.error('Error fetching AI coach advice:', err);
      setAiCoachError('No se pudo cargar el análisis táctico.');
    } finally {
      setLoadingAiCoach(false);
    }
  };

  const fetchSupabaseStatus = async () => {
    setLoadingSupabase(true);
    try {
      const data = await apiFetch<any>('/supabase/status');
      setSupabaseStatus(data);
    } catch (err) {
      console.error('Error fetching Supabase status:', err);
    } finally {
      setLoadingSupabase(false);
    }
  };

  useEffect(() => {
    fetchRooms();
    fetchHistory();
    fetchSupabaseStatus();
    fetchAiCoach();
  }, []);

  // Update max players based on selected pitch type
  useEffect(() => {
    const defaultMax = createPitchType === '5v5' ? 10 : createPitchType === '7v7' ? 14 : 22;
    setCreateMaxPlayers(defaultMax);
  }, [createPitchType]);

  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError('');

    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const todayStrLocal = `${year}-${month}-${day}`;

    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const nowTimeStrLocal = `${hours}:${minutes}`;

    if (!createDate || !createTime) {
      setCreateError('Por favor, selecciona una fecha y hora de inicio.');
      return;
    }

    if (createDate < todayStrLocal) {
      setCreateError('La fecha del partido no puede ser anterior al día de hoy.');
      return;
    }

    if (createDate === todayStrLocal && createTime < nowTimeStrLocal) {
      setCreateError('La hora del partido ya ha pasado hoy. Elige una hora futura.');
      return;
    }

    setCreating(true);

    try {
      const newRoom = await apiFetch<Room>('/rooms', {
        method: 'POST',
        body: JSON.stringify({
          title: createTitle,
          date: createDate,
          time: createTime,
          pitchType: createPitchType,
          maxPlayers: createMaxPlayers,
          expectedSR: Number(createExpectedSR),
          department: createDept || undefined,
          province: createProv || undefined,
          district: createDist || undefined,
          mapsUrl: createMapsUrl || undefined,
        }),
      });
      
      setShowCreateModal(false);
      // Reset form
      setCreateTitle('');
      setCreateDate('');
      setCreateTime('');
      setCreatePitchType('7v7');
      setCreateExpectedSR(1000);
      setCreateDept('');
      setCreateProv('');
      setCreateDist('');
      setCreateMapsUrl('');
      
      // Join immediately
      onJoinRoom(newRoom.id);
    } catch (err: any) {
      setCreateError(err.message || 'Error al crear el partido');
    } finally {
      setCreating(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileError('');

    const trimmedName = profileName.trim();
    if (!trimmedName) {
      setProfileError('Por favor, ingresa tu nombre completo o apodo.');
      return;
    }
    if (trimmedName.length < 3) {
      setProfileError('El nombre o apodo debe tener al menos 3 caracteres.');
      return;
    }
    if (trimmedName.length > 40) {
      setProfileError('El nombre o apodo no debe superar los 40 caracteres.');
      return;
    }

    const nameRegex = /^[a-zA-Z0-9áéíóúÁÉÍÓÚñÑüÜ\s'\-\"“”.]+$/;
    if (!nameRegex.test(trimmedName)) {
      setProfileError('El nombre solo puede contener letras, números, espacios, guiones, puntos y comillas para tu apodo.');
      return;
    }

    if (!profileDept || !profileProv || !profileDist) {
      setProfileError('Por favor, selecciona tu ubicación completa (Departamento, Provincia y Distrito).');
      return;
    }

    setUpdatingProfile(true);

    try {
      const updated = await apiFetch<User>('/profile', {
        method: 'PUT',
        body: JSON.stringify({
          name: trimmedName,
          preferredPosition: profilePosition,
          department: profileDept || undefined,
          province: profileProv || undefined,
          district: profileDist || undefined,
        }),
      });
      onUpdateUser(updated);
      setShowProfileModal(false);
    } catch (err: any) {
      setProfileError(err.message || 'Error al actualizar perfil');
    } finally {
      setUpdatingProfile(false);
    }
  };

  // Logout handler
  const handleLogoutClick = () => {
    removeToken();
    onLogout();
  };

  // Filtering Rooms
  const filteredRooms = rooms.filter((room) => {
    if (room.state === 'finished') return false;
    const matchesPitch = filterPitch === 'Todos' || room.pitchType === filterPitch;
    const matchesSearch = room.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          room.creatorName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesPitch && matchesSearch;
  });

  const finishedRooms = rooms.filter((room) => {
    if (room.state !== 'finished') return false;
    if (!room.players.includes(user.id)) return false;
    const matchesPitch = filterPitch === 'Todos' || room.pitchType === filterPitch;
    const matchesSearch = room.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          room.creatorName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesPitch && matchesSearch;
  });

  const winRate = user.matchesPlayed > 0 
    ? Math.round((user.wins / user.matchesPlayed) * 100) 
    : 0;

  const positionsLabels: Record<Position, string> = {
    GK: 'Portero (GK)',
    DEF: 'Defensa (DEF)',
    MID: 'Medio (MID)',
    FWD: 'Delantero (FWD)'
  };

  const sidebarContent = (
    <>
      {/* Player Bento Card */}
      <div className="bg-[#151B22] rounded-3xl p-6 border border-gray-800 shadow-2xl relative overflow-hidden flex flex-col justify-between" id="player-sidebar-card">
        {/* Decorative pitch circle highlight */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-green-500/5 rounded-full -mr-8 -mt-8 pointer-events-none border border-green-500/5" />
        
        <div>
          <p className="text-[10px] font-bold text-green-500 uppercase tracking-widest mb-4">Perfil de Jugador</p>
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-14 h-14 bg-gradient-to-tr from-green-600 to-emerald-400 rounded-2xl flex items-center justify-center text-black font-black text-xl shadow-md shadow-green-500/10 shrink-0">
              {user.name.slice(0, 2).toUpperCase()}
            </div>
            <div className="min-w-0">
              <h2 className="font-black font-display text-lg text-white uppercase italic tracking-tight truncate leading-none mb-1">
                {user.name}
              </h2>
              <span className="text-[9px] text-gray-500 font-mono">ID: {user.id}</span>
              <div className="mt-1 flex items-center">
                <span className="text-[9px] px-2.5 py-0.5 font-extrabold rounded-md bg-green-500/10 border border-green-500/20 text-green-400 uppercase tracking-widest">
                  {positionsLabels[user.preferredPosition]}
                </span>
              </div>
            </div>
          </div>

          {/* Skill Rating Bento Tracker */}
          <div className="bg-gray-950/60 border border-gray-800/80 rounded-2xl p-4 text-white relative overflow-hidden mb-6">
            <div className="absolute right-3 bottom-0 text-white/5 font-black text-7xl pointer-events-none italic">
              SR
            </div>
            <div className="flex justify-between items-center relative z-10">
              <div>
                <span className="text-[9px] text-gray-400 font-bold uppercase tracking-wider block">
                  Skill Rating (SR)
                </span>
                <span className="text-4xl font-black font-display text-white italic tracking-tight block mt-1">
                  {user.skillRating}
                </span>
              </div>
              <div className="px-3 py-1 bg-green-500/10 border border-green-500/20 rounded-full text-[10px] font-black uppercase text-green-400 flex items-center">
                <Award className="w-3.5 h-3.5 mr-1" />
                PLATINUM III
              </div>
            </div>

            {/* Dynamic Progress Bar */}
            <div className="space-y-1.5 mt-4">
              <div className="h-1.5 w-full bg-gray-800 rounded-full">
                <div 
                  className="h-full bg-green-500 rounded-full transition-all duration-500"
                  style={{ width: `${Math.min(100, Math.max(10, (user.skillRating / 2000) * 100))}%` }}
                ></div>
              </div>
              <div className="flex justify-between items-center text-[8px] text-gray-500 font-bold tracking-wider">
                <span>BRONZE</span>
                <span className="text-green-500 font-extrabold">ACTUAL</span>
                <span>ELITE</span>
              </div>
            </div>
          </div>

          {/* Matches Stats Bento Grid */}
          <div className="grid grid-cols-3 gap-3 text-center mb-6">
            <div className="p-3 bg-gray-950/40 rounded-xl border border-gray-800/40">
              <span className="text-[9px] uppercase font-bold text-gray-500 block tracking-wider">Partidos</span>
              <span className="text-lg font-black text-white mt-0.5 block italic">{user.matchesPlayed}</span>
            </div>
            <div className="p-3 bg-green-500/5 rounded-xl border border-green-500/10">
              <span className="text-[9px] uppercase font-bold text-green-400 block tracking-wider">Wins</span>
              <span className="text-lg font-black text-green-400 mt-0.5 block italic">{user.wins}</span>
            </div>
            <div className="p-3 bg-gray-950/40 rounded-xl border border-gray-800/40">
              <span className="text-[9px] uppercase font-bold text-gray-500 block tracking-wider">Win Rate</span>
              <span className="text-lg font-black text-white mt-0.5 block italic">{winRate}%</span>
            </div>
          </div>
        </div>

        {/* Supabase Integration Status - Only visible to developer/administrator */}
        {user.email === 'hernanhhv69@gmail.com' && (
          <div className="mb-4 p-2.5 bg-gray-950/40 rounded-xl border border-gray-800/40 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${supabaseStatus?.connection ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
              <div className="text-left">
                <span className="text-[8px] text-gray-500 font-bold uppercase tracking-wider block">NUBE (SUPABASE)</span>
                <span className="text-[10px] text-white font-bold uppercase">
                  {supabaseStatus?.connection ? 'Conectado' : 'Local / Sin Tablas'}
                </span>
              </div>
            </div>
            <button 
              onClick={() => setShowSupabaseModal(true)}
              className="px-2 py-1 bg-[#151B22] hover:bg-gray-800 border border-gray-800 text-[9px] font-black uppercase text-green-400 rounded-lg transition-colors cursor-pointer"
            >
              Configurar
            </button>
          </div>
        )}

        {/* Record Summary Table row */}
        <div className="flex justify-between items-center text-[10px] text-gray-400 uppercase font-semibold px-1 border-t border-gray-800/50 pt-4">
          <span>Vic: <strong className="text-white font-black">{user.wins}</strong></span>
          <span>Def: <strong className="text-white font-black">{user.losses}</strong></span>
          <span>Emp: <strong className="text-white font-black">{user.draws}</strong></span>
        </div>
      </div>

      {/* AI Performance Coach Bento Card */}
      <div className="bg-[#151B22] rounded-3xl p-6 border border-gray-800 shadow-2xl relative overflow-hidden" id="ai-coach-bento-card">
        {/* Background glow overlay */}
        <div className="absolute top-0 right-0 w-36 h-36 bg-green-500/5 rounded-full -mr-10 -mt-10 pointer-events-none blur-xl" />
        
        {/* Card Header */}
        <div className="flex justify-between items-start mb-4 relative z-10">
          <div className="flex items-center space-x-2">
            <div className="p-2 bg-green-500/10 border border-green-500/20 rounded-xl">
              <Brain className="w-5 h-5 text-green-400 animate-pulse" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-green-500 uppercase tracking-widest leading-none mb-1">AI Performance Coach</p>
              <h3 className="font-black font-display text-sm text-white uppercase italic tracking-tight">Coach de Rendimiento</h3>
            </div>
          </div>
          <button 
            onClick={fetchAiCoach}
            disabled={loadingAiCoach}
            className="p-1.5 bg-gray-950 hover:bg-gray-800 disabled:opacity-50 text-gray-500 hover:text-green-400 rounded-lg border border-gray-800 transition-colors"
            title="Analizar Nuevamente"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loadingAiCoach ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {loadingAiCoach ? (
          <div className="py-8 text-center space-y-4">
            <div className="relative w-12 h-12 mx-auto">
              <div className="absolute inset-0 border-4 border-green-500/20 rounded-full animate-pulse" />
              <div className="absolute inset-0 border-4 border-green-500 border-t-transparent rounded-full animate-spin" />
              <Brain className="w-5 h-5 text-green-400 absolute inset-0 m-auto animate-pulse" />
            </div>
            <div className="space-y-1">
              <p className="text-[10px] font-bold text-green-400 uppercase tracking-widest animate-pulse font-mono">Dibujando Pizarra Táctica...</p>
              <p className="text-[9px] text-gray-500 uppercase font-mono">Analizando rendimiento real en la base de datos</p>
            </div>
          </div>
        ) : aiCoachError ? (
          <div className="py-6 text-center space-y-3 bg-rose-950/10 border border-rose-900/20 rounded-2xl p-4">
            <ShieldAlert className="w-6 h-6 text-rose-500 mx-auto" />
            <p className="text-[10px] uppercase font-bold text-rose-400 leading-tight">{aiCoachError}</p>
            <button 
              onClick={fetchAiCoach}
              className="px-3 py-1 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-[9px] font-black uppercase rounded-lg border border-rose-500/30 transition-colors"
            >
              Reintentar
            </button>
          </div>
        ) : aiCoach ? (
          <div className="space-y-4 text-left">
            
            {/* Tactical Playstyle Badge */}
            <div className="flex items-center space-x-2">
              <span className="text-[8px] text-gray-500 font-bold uppercase tracking-wider font-mono">Rango AI:</span>
              <div className="px-3 py-1 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-full text-[10px] font-black uppercase flex items-center shadow-lg shadow-amber-500/5">
                <Sparkles className="w-3.5 h-3.5 mr-1 text-amber-400" />
                {aiCoach.playstyleBadge}
              </div>
            </div>

            {/* Tactical Summary */}
            <div className="p-3 bg-gray-950/50 border border-gray-800/60 rounded-2xl text-xs text-gray-300 leading-relaxed font-semibold">
              <p>{aiCoach.tacticalSummary}</p>
            </div>

            {/* Strengths & Weaknesses */}
            <div className="grid grid-cols-1 gap-3">
              {/* Strengths */}
              <div className="space-y-1.5">
                <p className="text-[9px] font-bold text-green-400 uppercase tracking-widest flex items-center">
                  <Zap className="w-3 h-3 mr-1 text-green-400" /> Fortalezas Detectadas
                </p>
                <ul className="space-y-1">
                  {aiCoach.strengths?.map((str, idx) => (
                    <li key={idx} className="text-[10px] text-gray-400 flex items-start">
                      <span className="text-green-500 mr-1.5 font-bold">✓</span>
                      <span>{str}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Areas to improve */}
              <div className="space-y-1.5 border-t border-gray-800/40 pt-2.5">
                <p className="text-[9px] font-bold text-amber-400 uppercase tracking-widest flex items-center">
                  <TrendingUp className="w-3 h-3 mr-1 text-amber-400" /> Áreas de Crecimiento
                </p>
                <ul className="space-y-1">
                  {aiCoach.weaknesses?.map((weak, idx) => (
                    <li key={idx} className="text-[10px] text-gray-400 flex items-start">
                      <span className="text-amber-500 mr-1.5 font-bold">⚡</span>
                      <span>{weak}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Drills Exercises Accordion/Cards */}
            <div className="border-t border-gray-800/40 pt-3 space-y-2">
              <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest flex items-center">
                <Dumbbell className="w-3.5 h-3.5 mr-1 text-green-400" /> Plan de Entrenamientos
              </p>
              
              <div className="space-y-2">
                {aiCoach.drills?.map((drill, idx) => (
                  <div key={idx} className="p-2.5 bg-gray-950/40 rounded-xl border border-gray-900 flex flex-col justify-between gap-1">
                    <div className="flex justify-between items-start">
                      <span className="text-[10px] font-black text-white uppercase italic">{drill.name}</span>
                      <span className="text-[8px] font-mono font-bold px-1.5 py-0.5 rounded bg-green-500/10 text-green-400 border border-green-500/20">{drill.duration}</span>
                    </div>
                    <p className="text-[9px] text-gray-500 font-semibold uppercase leading-tight">{drill.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Source Meta indicator */}
            <div className="flex justify-between items-center text-[8px] text-gray-600 font-mono font-bold uppercase pt-1">
              <span>Modelo: Gemini 2.5 Flash</span>
              <span className={`text-[8px] font-bold ${aiCoach.source === 'gemini_api' ? 'text-green-500' : 'text-gray-500'}`}>
                {aiCoach.source === 'gemini_api' ? 'Conexión AI Live' : 'Motor Táctico Local'}
              </span>
            </div>

          </div>
        ) : (
          <div className="py-6 text-center">
            <button 
              onClick={fetchAiCoach}
              className="px-4 py-2 bg-green-500 hover:bg-green-400 text-black font-black uppercase text-xs rounded-xl shadow-lg"
            >
              Cargar Análisis de Rendimiento
            </button>
          </div>
        )}
      </div>

      {/* HISTORIAL / PARTIDOS RECIENTES (Bento Card) */}
      <div className="bg-[#151B22] rounded-3xl p-6 border border-gray-800 shadow-2xl" id="sidebar-match-history">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-black text-xs text-gray-400 uppercase italic tracking-widest">
            Historial de Partidos
          </h3>
          <button 
            onClick={fetchHistory}
            className="p-1.5 bg-gray-950 hover:bg-gray-800 text-gray-500 hover:text-green-400 rounded-lg border border-gray-800 transition-colors"
            title="Actualizar Historial"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {loadingHistory ? (
          <div className="py-8 text-center text-xs text-gray-500 font-mono uppercase">Cargando historial...</div>
        ) : history.length === 0 ? (
          <div className="py-10 text-center border border-dashed border-gray-800 rounded-2xl">
            <p className="text-xs text-gray-400 font-bold uppercase tracking-wider">Aún no hay partidos jugados</p>
            <p className="text-[10px] text-gray-500 mt-1 uppercase">¡Únete a una sala para comenzar!</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-[380px] overflow-y-auto custom-scrollbar pr-1">
            {history.map((item) => {
              const isWin = item.result === 'win';
              const isLoss = item.result === 'loss';
              
              return (
                <div 
                  key={item.id}
                  className="p-3 bg-gray-950/40 rounded-2xl border border-gray-800/40 flex items-center justify-between hover:border-gray-800 transition-colors"
                >
                  <div className="min-w-0 flex-1 pr-3">
                    <span className="text-xs font-bold text-white block truncate uppercase tracking-tight">
                      {item.title}
                    </span>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className="text-[9px] text-gray-500 font-bold uppercase">
                        Cancha {item.pitchType}
                      </span>
                      <span className="text-gray-700 font-bold">•</span>
                      <span className="text-[10px] text-green-400 font-mono font-bold">
                        {item.scoreA} - {item.scoreB}
                      </span>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className={`text-[8px] font-black px-2 py-0.5 rounded uppercase tracking-wider block text-center ${
                      isWin 
                        ? 'bg-green-500/10 text-green-400 border border-green-500/20' 
                        : isLoss 
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' 
                        : 'bg-gray-800 text-gray-400'
                    }`}>
                      {isWin ? 'Win' : isLoss ? 'Loss' : 'Draw'}
                    </span>
                    <span className={`text-[11px] font-black block mt-1 font-mono ${
                      item.srChange >= 0 ? 'text-green-400' : 'text-rose-500'
                    }`}>
                      {item.srChange >= 0 ? `+${item.srChange}` : item.srChange} SR
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-[#0B0F13] text-gray-100 font-sans pb-16 px-4 md:px-6" id="dashboard-layout">
      {/* HEADER NAVBAR - Bento Box style floating header */}
      <div className="max-w-7xl mx-auto pt-6">
        <header className="flex flex-col sm:flex-row items-center justify-between bg-[#151B22] p-4 rounded-2xl border border-gray-800 shadow-xl gap-4" id="navbar">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center text-black font-black text-xl italic shadow-lg shadow-green-500/20">SF</div>
            <h1 className="text-xl font-bold tracking-tight text-white italic underline underline-offset-4 decoration-green-500">STRIKER.FORCE</h1>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-6 items-center w-full sm:w-auto justify-end">
            <nav className="flex gap-6 text-xs font-bold text-gray-400 uppercase tracking-widest">
              <span className="text-green-400 border-b-2 border-green-500 pb-1 cursor-pointer">Matchmaking</span>
              <span className="hover:text-white cursor-pointer transition-colors" onClick={() => setShowProfileModal(true)}>Mi Perfil</span>
            </nav>
            <div className="flex items-center gap-3 pl-0 sm:pl-6 border-t sm:border-t-0 sm:border-l border-gray-800 pt-3 sm:pt-0 w-full sm:w-auto justify-center sm:justify-end">
              <div className="text-right">
                <p className="text-[10px] text-gray-500 leading-tight uppercase font-mono">Bienvenido,</p>
                <p className="text-xs font-bold text-white uppercase">{user.name}</p>
              </div>
              <button
                onClick={() => setShowProfileModal(true)}
                className="w-10 h-10 rounded-full border-2 border-green-500 bg-gray-800 flex items-center justify-center text-white font-extrabold text-sm uppercase shadow-md shadow-green-500/10 cursor-pointer hover:scale-105 transition-transform"
                title="Configuración de Perfil"
                id="edit-profile-trigger"
              >
                {user.name.slice(0, 2)}
              </button>

              <button
                onClick={() => setShowMobileSidebar(true)}
                className="lg:hidden p-2.5 bg-gray-950 hover:bg-gray-800 border border-gray-800 hover:border-green-500/50 text-green-400 rounded-xl transition-all flex items-center justify-center"
                title="Estadísticas y Historial"
                id="header-mobile-sidebar-toggle"
              >
                <Trophy className="w-4 h-4" />
              </button>
              
              <button
                onClick={handleLogoutClick}
                className="p-2.5 bg-gray-950 hover:bg-rose-950/20 border border-gray-800 hover:border-rose-900/40 text-gray-400 hover:text-rose-400 rounded-xl transition-all"
                title="Cerrar Sesión"
                id="logout-btn"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </header>
      </div>

      {/* DASHBOARD HERO GRID */}
      <main className="max-w-7xl mx-auto mt-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="dashboard-grid">
          
          {/* LEFT SIDEBAR BENTO PANEL: PROFILE & STATISTICS (col-span-4) */}
          <div className="hidden lg:block lg:col-span-4 space-y-6" id="dashboard-profile-section">
            {sidebarContent}
          </div>

          {/* RIGHT VIEW BENTO PANEL: MATCHROOMS LIST (col-span-8) */}
          <div className="lg:col-span-8 space-y-6" id="dashboard-main-section">
            
            {/* LOBBY FILTERS & ACTIONS (Bento Card) */}
            <div className="bg-[#151B22] rounded-3xl p-6 border border-gray-800 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <h2 className="text-2xl font-black uppercase italic tracking-tight text-white">
                  Convocatorias Activas
                </h2>
                <p className="text-gray-500 text-[10px] uppercase font-bold tracking-wider flex items-center gap-2">
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                  Matchmaking en curso • Algoritmo de balanceo activo
                </p>
              </div>

              <div className="flex items-center space-x-3 shrink-0 w-full md:w-auto justify-end">
                <button
                  onClick={() => setShowMobileSidebar(true)}
                  className="lg:hidden w-full md:w-auto px-4 py-2.5 bg-gray-950 hover:bg-gray-800 border border-gray-800 hover:border-gray-700 text-green-400 font-black uppercase tracking-tighter transition-all rounded-xl shadow-lg italic text-xs flex items-center justify-center"
                  id="mobile-sidebar-toggle-btn"
                >
                  <Trophy className="w-4 h-4 mr-1.5 shrink-0" />
                  Ver Stats
                </button>

                <button
                  onClick={() => setShowCreateModal(true)}
                  className="w-full md:w-auto px-4 py-2.5 bg-green-500 hover:bg-green-400 text-black font-black uppercase tracking-tighter transition-all rounded-xl shadow-lg shadow-green-500/20 italic text-xs flex items-center justify-center"
                  id="create-match-trigger"
                >
                  <Plus className="w-4 h-4 mr-1.5" />
                  Crear Partido
                </button>
                
                <button
                  onClick={fetchRooms}
                  className="p-2.5 bg-gray-950 hover:bg-gray-800 text-gray-400 hover:text-white rounded-xl border border-gray-800 transition-colors"
                  title="Actualizar Salas"
                >
                  <RefreshCw className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* SEARCH AND PITCH TYPE FILTER BAR */}
            <div className="flex flex-col sm:flex-row gap-4 items-center">
              <div className="relative flex-1 w-full">
                <Search className="absolute inset-y-0 left-0 pl-3.5 flex items-center text-gray-600 w-5 h-5 my-auto" />
                <input
                  type="text"
                  placeholder="Buscar partido por título o creador..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-11 pr-4 py-2.5 bg-[#151B22] border border-gray-800 rounded-2xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 transition-all text-xs uppercase font-semibold tracking-wider shadow-sm"
                  id="search-input"
                />
              </div>

              {/* Pitch Type Filter Buttons */}
              <div className="flex bg-gray-950 p-1 rounded-2xl w-full sm:w-auto shrink-0 border border-gray-800/60" id="pitch-filters">
                {['Todos', '5v5', '7v7', '11v11'].map((pitch) => (
                  <button
                    key={pitch}
                    onClick={() => setFilterPitch(pitch)}
                    className={`px-4 py-1.5 text-[10px] font-black rounded-xl transition-all uppercase flex-1 sm:flex-initial ${
                      filterPitch === pitch
                        ? 'bg-[#151B22] border border-gray-800 text-green-400 shadow-sm'
                        : 'text-gray-500 hover:text-gray-300'
                    }`}
                    id={`filter-pitch-${pitch}`}
                  >
                    {pitch}
                  </button>
                ))}
              </div>
            </div>

            {/* ACTIVE ROOMS LIST */}
            {loadingRooms ? (
              <div className="bg-[#151B22] rounded-3xl p-12 text-center border border-gray-800 shadow-xl text-gray-500">
                <div className="animate-spin inline-block w-8 h-8 border-4 border-green-500 border-t-transparent rounded-full mb-3" />
                <p className="text-xs uppercase font-bold tracking-widest font-mono">Buscando convocatorias de juego...</p>
              </div>
            ) : filteredRooms.length === 0 ? (
              <div className="bg-[#151B22] rounded-3xl p-16 text-center border border-gray-800 shadow-xl">
                <div className="inline-flex p-4 bg-gray-950 rounded-3xl text-gray-600 border border-gray-800 mb-4">
                  <Search className="w-8 h-8" />
                </div>
                <h4 className="font-black text-white text-lg uppercase italic tracking-tight">No se encontraron salas</h4>
                <p className="text-gray-500 text-xs mt-1 max-w-sm mx-auto uppercase font-bold tracking-wider">
                  No hay salas activas con los filtros actuales.
                </p>
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="mt-5 px-5 py-2.5 bg-green-500 hover:bg-green-400 text-black font-black rounded-xl shadow-lg transition-all text-xs inline-flex items-center uppercase italic"
                >
                  <Plus className="w-4 h-4 mr-1.5" />
                  Crear Primera Convocatoria
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="rooms-grid">
                {filteredRooms.map((room) => {
                  const isFull = room.players.length >= room.maxPlayers;
                  const isUserInRoom = room.players.includes(user.id);
                  const isLobby = room.state === 'lobby';
                  const isStarted = room.state === 'started';
                  const isFinished = room.state === 'finished';

                  // Type casting to check recommended fields injected by endpoint
                  const r = room as any;
                  const isRecommended = r.isRecommended;
                  const skillMatchScore = r.skillMatchScore;

                  return (
                    <motion.div
                      layout
                      key={room.id}
                      className={`bg-[#151B22] rounded-3xl p-5 border shadow-xl transition-all flex flex-col justify-between group ${
                        isUserInRoom 
                          ? 'border-green-500/80 ring-1 ring-green-500/10' 
                          : isRecommended && isLobby
                          ? 'border-amber-500/30 shadow-amber-500/5'
                          : 'border-gray-800/80 hover:border-gray-700'
                      }`}
                      id={`room-card-${room.id}`}
                    >
                      <div>
                        {/* Header Badge Row */}
                        <div className="flex justify-between items-start gap-2 mb-3">
                          <span className="text-[9px] px-2 py-0.5 rounded font-black uppercase tracking-wider bg-green-500/10 border border-green-500/20 text-green-400">
                            Cancha {room.pitchType}
                          </span>

                          <div className="flex space-x-1 shrink-0">
                            {isRecommended && isLobby && (
                              <span className="text-[9px] px-2 py-0.5 rounded font-black uppercase tracking-wider bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center">
                                <Sparkles className="w-3 h-3 mr-1" />
                                Recomendado
                              </span>
                            )}
                            {isStarted && (
                              <span className="text-[9px] px-2 py-0.5 rounded font-black uppercase tracking-wider bg-blue-500/10 text-blue-400 border border-blue-500/20">
                                En Curso
                              </span>
                            )}
                            {isFinished && (
                              <span className="text-[9px] px-2 py-0.5 rounded font-black uppercase tracking-wider bg-gray-800 text-gray-400">
                                Finalizado
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Room Title */}
                        <h4 className="font-black font-display text-white text-base leading-tight mb-1 truncate uppercase italic tracking-tight group-hover:text-green-400 transition-colors">
                          {room.title}
                        </h4>

                        {/* Organizer Name */}
                        <p className="text-[10px] text-gray-500 uppercase tracking-wider font-bold mb-2">
                          Organiza: <span className="text-gray-300 font-extrabold">{room.creatorName}</span>
                        </p>

                        {/* Location Details */}
                        {room.department && (
                          <div className="flex items-center text-[10px] text-green-400 font-bold uppercase tracking-wider mb-4 gap-1">
                            <MapPin className="w-3.5 h-3.5 text-green-500 shrink-0" />
                            <span>{room.department} • {room.province} • {room.district}</span>
                          </div>
                        )}

                        {/* Match Logistics Metadata */}
                        <div className="space-y-2 mb-5 text-[11px] text-gray-400 uppercase font-semibold">
                          <div className="flex items-center">
                            <Calendar className="w-3.5 h-3.5 mr-2 text-gray-500 shrink-0" />
                            <span>{room.date}</span>
                          </div>
                          <div className="flex items-center">
                            <Clock className="w-3.5 h-3.5 mr-2 text-gray-500 shrink-0" />
                            <span>{room.time} HS</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <Trophy className="w-3.5 h-3.5 mr-2 text-gray-500 shrink-0" />
                              <span>Nivel: <strong className="text-white font-black font-mono">{room.expectedSR} SR</strong></span>
                            </div>
                            {isLobby && skillMatchScore && (
                              <span className="text-[9px] font-black font-mono text-green-400">
                                Afinidad: {skillMatchScore}%
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Footer Player Count and Button */}
                      <div className="border-t border-gray-800/60 pt-3 mt-3 flex items-center justify-between">
                        <div className="flex items-center text-gray-400 text-xs font-mono font-bold">
                          <Users className="w-4 h-4 mr-1 text-gray-500" />
                          <span>
                            <strong>{room.players.length}</strong> / {room.maxPlayers}
                          </span>
                        </div>

                        {isFinished ? (
                          <button
                            onClick={() => onJoinRoom(room.id)}
                            className="text-[10px] font-black uppercase text-gray-400 hover:text-white flex items-center"
                            id={`room-view-${room.id}`}
                          >
                            Ver Resultado <ChevronRight className="w-4 h-4 ml-0.5" />
                          </button>
                        ) : (
                          <button
                            onClick={() => onJoinRoom(room.id)}
                            className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all flex items-center ${
                              isUserInRoom
                                ? 'bg-green-500/10 text-green-400 hover:bg-green-500/20 border border-green-500/30'
                                : isFull
                                ? 'bg-gray-950 text-gray-600 border border-gray-900 cursor-not-allowed'
                                : 'bg-green-500 hover:bg-green-400 text-black font-black uppercase italic'
                            }`}
                            id={`room-action-${room.id}`}
                          >
                            {isUserInRoom ? 'Entrar' : isFull ? 'Lleno' : 'Unirse'}
                            <ChevronRight className="w-3.5 h-3.5 ml-1" />
                          </button>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}

            {/* FINISHED ROOMS SECTION */}
            <div className="space-y-4 pt-6 border-t border-gray-800/50">
              <div className="space-y-1">
                <h3 className="text-lg font-black uppercase italic tracking-tight text-gray-400">
                  Partidos Finalizados
                </h3>
                <p className="text-gray-600 text-[10px] uppercase font-bold tracking-wider">
                  Historial de encuentros disputados y cerrados oficialmente
                </p>
              </div>

              {finishedRooms.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="finished-rooms-grid">
                  {finishedRooms.map((room) => {
                    const isUserInRoom = room.players.includes(user.id);
                    return (
                      <motion.div
                        layout
                        key={room.id}
                        className="bg-[#151B22]/50 rounded-3xl p-5 border border-gray-800/40 hover:border-gray-800/80 shadow-xl transition-all flex flex-col justify-between group"
                        id={`finished-room-card-${room.id}`}
                      >
                        <div>
                          {/* Header Badge Row */}
                          <div className="flex justify-between items-start gap-2 mb-3">
                            <span className="text-[9px] px-2 py-0.5 rounded font-black uppercase tracking-wider bg-gray-800/40 border border-gray-800/60 text-gray-500">
                              Cancha {room.pitchType}
                            </span>
                            <span className="text-[9px] px-2 py-0.5 rounded font-black uppercase tracking-wider bg-green-500/10 text-green-400 border border-green-500/20">
                              Finalizado
                            </span>
                          </div>

                          {/* Room Title */}
                          <h4 className="font-black font-display text-gray-300 text-base leading-tight mb-1 truncate uppercase italic tracking-tight group-hover:text-green-400 transition-colors">
                            {room.title}
                          </h4>

                          {/* Organizer Name */}
                          <p className="text-[10px] text-gray-600 uppercase tracking-wider font-bold mb-2">
                            Organizó: <span className="text-gray-400 font-extrabold">{room.creatorName}</span>
                          </p>

                          {/* Location Details */}
                          {room.department && (
                            <div className="flex items-center text-[10px] text-gray-500 font-bold uppercase tracking-wider mb-4 gap-1">
                              <MapPin className="w-3.5 h-3.5 text-gray-600 shrink-0" />
                              <span>{room.department} • {room.province} • {room.district}</span>
                            </div>
                          )}

                          {/* Match Score Display */}
                          <div className="bg-gray-950/40 rounded-2xl p-3 border border-gray-900 flex justify-between items-center mb-4">
                            <div>
                              <span className="text-[8px] text-gray-500 font-bold uppercase tracking-wider block">Resultado Oficial</span>
                              <span className="text-xs font-black text-gray-400 uppercase">Marcador</span>
                            </div>
                            <div className="text-right">
                              <span className="text-xl font-black font-mono text-green-400 italic">
                                {room.scoreA} - {room.scoreB}
                              </span>
                            </div>
                          </div>

                          {/* Match Logistics Metadata */}
                          <div className="space-y-2 mb-5 text-[11px] text-gray-500 uppercase font-semibold">
                            <div className="flex items-center">
                              <Calendar className="w-3.5 h-3.5 mr-2 text-gray-600 shrink-0" />
                              <span>{room.date}</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <Trophy className="w-3.5 h-3.5 mr-2 text-gray-600 shrink-0" />
                                <span>Nivel: <strong className="text-gray-400 font-black font-mono">{room.expectedSR} SR</strong></span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Footer Player Count and Button */}
                        <div className="border-t border-gray-800/40 pt-3 mt-3 flex items-center justify-between">
                          <div className="flex items-center text-gray-500 text-xs font-mono font-bold">
                            <Users className="w-4 h-4 mr-1 text-gray-600" />
                            <span>
                              <strong>{room.players.length}</strong> / {room.maxPlayers}
                            </span>
                          </div>

                          <button
                            onClick={() => onJoinRoom(room.id)}
                            className="text-[10px] font-black uppercase text-green-500 hover:text-green-400 flex items-center"
                            id={`finished-room-view-${room.id}`}
                          >
                            Ver Detalles <ChevronRight className="w-4 h-4 ml-0.5" />
                          </button>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              ) : (
                <div className="bg-[#151B22]/20 border border-dashed border-gray-800 rounded-3xl p-10 text-center" id="no-finished-rooms">
                  <p className="text-gray-400 text-sm font-black uppercase tracking-wider italic">
                    todavia notienes un historial de partidas, ve y JUEGAA
                  </p>
                </div>
              )}
            </div>

            {/* DYNAMIC MAP/LOCATION BENTO CARD (Decorative / Informational Layout element) */}
            <section className="col-span-12 bg-gradient-to-br from-[#1C252E] to-[#151B22] rounded-3xl border border-gray-800 p-5 flex items-center justify-center relative overflow-hidden h-40 shadow-xl">
              <div className="absolute inset-0 opacity-10 pointer-events-none">
                {/* Field Grid Map Pattern */}
                <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <pattern id="bento-field-grid" width="30" height="30" patternUnits="userSpaceOnUse">
                      <path d="M 30 0 L 0 0 0 30" fill="none" stroke="white" strokeWidth="0.5"/>
                    </pattern>
                  </defs>
                  <rect width="100%" height="100%" fill="url(#bento-field-grid)" />
                </svg>
              </div>
              <div className="z-10 text-center">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-2 shadow-lg shadow-green-500/30">
                  <svg className="w-6 h-6 text-black" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/>
                  </svg>
                </div>
                <p className="text-sm font-black uppercase text-white italic tracking-tight">Sedes Oficiales Cercanas</p>
                <p className="text-[10px] text-gray-500 uppercase font-bold mt-1 tracking-wider">Hay 8 canchas registradas en tu zona de emparejamiento</p>
              </div>
            </section>

            {/* ALGORITHM ENGINE FOOTER BLOCK */}
            <div className="p-3 bg-black/40 rounded-xl border border-gray-800 flex items-center justify-between text-[9px] uppercase font-bold text-gray-500 tracking-wider">
              <span>Matchmaking Engine v2.5</span>
              <span className="text-green-500">ALGORITMO DE BALANCEO ACTIVO</span>
            </div>

          </div>
        </div>
      </main>

      {/* --- CREATE ROOM MODAL --- */}
      <AnimatePresence>
        {showCreateModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" id="create-room-modal-backdrop">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-[#151B22] rounded-3xl max-w-md w-full shadow-2xl border border-gray-800 overflow-hidden relative z-50 text-white"
              id="create-room-modal"
            >
              <div className="bg-gradient-to-r from-green-600 to-emerald-700 px-6 py-4 flex justify-between items-center text-white border-b border-gray-800">
                <div className="flex items-center space-x-2">
                  <Trophy className="w-5 h-5 text-green-200" />
                  <h3 className="font-extrabold font-display text-base">Convocar Nuevo Partido</h3>
                </div>
                <button 
                  onClick={() => setShowCreateModal(false)}
                  className="text-white/80 hover:text-white p-1 hover:bg-white/10 rounded-lg transition-colors"
                  id="close-create-modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {createError && (
                <div className="p-4 bg-rose-500/10 border-b border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center">
                  <ShieldAlert className="w-4 h-4 mr-2" />
                  <span>{createError}</span>
                </div>
              )}

              <form onSubmit={handleCreateRoom} className="p-6 space-y-4" id="create-room-form">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">Título del Partido</label>
                  <input
                    type="text"
                    required
                    placeholder="Ej: Partido de los Martes en Pichincha"
                    value={createTitle}
                    onChange={(e) => setCreateTitle(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 transition-all text-sm"
                    id="create-title-input"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">Fecha</label>
                    <input
                      type="date"
                      required
                      min={todayStr}
                      value={createDate}
                      onChange={(e) => setCreateDate(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 transition-all text-sm color-white"
                      id="create-date-input"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">Hora</label>
                    <input
                      type="time"
                      required
                      value={createTime}
                      onChange={(e) => setCreateTime(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 transition-all text-sm"
                      id="create-time-input"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">Tipo de Cancha</label>
                  <div className="grid grid-cols-3 gap-2 bg-gray-950 p-1 rounded-xl border border-gray-800">
                    {(['5v5', '7v7', '11v11'] as PitchType[]).map((pitch) => (
                      <button
                        key={pitch}
                        type="button"
                        onClick={() => setCreatePitchType(pitch)}
                        className={`py-2 text-xs font-bold rounded-lg transition-all ${
                          createPitchType === pitch
                            ? 'bg-[#151B22] text-green-400 border border-gray-800 shadow-sm'
                            : 'text-gray-500 hover:text-gray-300'
                        }`}
                        id={`create-pitch-select-${pitch}`}
                      >
                        {pitch}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Lugar del Partido */}
                <div className="space-y-2 pt-1 border-t border-gray-800/50" id="create-room-location-group">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">Lugar del Partido</label>
                  <div className="grid grid-cols-3 gap-2">
                    {/* Departamento */}
                    <div className="space-y-1">
                      <span className="text-[8px] font-bold text-gray-400 block uppercase">Dpto.</span>
                      <select
                        required
                        value={createDept}
                        onChange={(e) => {
                          setCreateDept(e.target.value);
                          setCreateProv('');
                          setCreateDist('');
                        }}
                        className="w-full px-2 py-1.5 bg-gray-950 border border-gray-800 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 text-xs transition-all"
                      >
                        <option value="">Elegir...</option>
                        {PERU_LOCATIONS.map((dept) => (
                          <option key={dept.name} value={dept.name}>{dept.name}</option>
                        ))}
                      </select>
                    </div>

                    {/* Provincia */}
                    <div className="space-y-1">
                      <span className="text-[8px] font-bold text-gray-400 block uppercase">Prov.</span>
                      <select
                        required
                        disabled={!createDept}
                        value={createProv}
                        onChange={(e) => {
                          setCreateProv(e.target.value);
                          setCreateDist('');
                        }}
                        className="w-full px-2 py-1.5 bg-gray-950 border border-gray-800 disabled:border-gray-900 disabled:text-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 text-xs transition-all"
                      >
                        <option value="">Elegir...</option>
                        {createProvincesList.map((prov) => (
                          <option key={prov.name} value={prov.name}>{prov.name}</option>
                        ))}
                      </select>
                    </div>

                    {/* Distrito */}
                    <div className="space-y-1">
                      <span className="text-[8px] font-bold text-gray-400 block uppercase">Dist.</span>
                      <select
                        required
                        disabled={!createProv}
                        value={createDist}
                        onChange={(e) => setCreateDist(e.target.value)}
                        className="w-full px-2 py-1.5 bg-gray-950 border border-gray-800 disabled:border-gray-900 disabled:text-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 text-xs transition-all"
                      >
                        <option value="">Elegir...</option>
                        {createDistrictsList.map((dist) => (
                          <option key={dist} value={dist}>{dist}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                {/* Google Maps Link */}
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">Link de Google Maps (Opcional)</label>
                  <input
                    type="url"
                    placeholder="https://maps.google.com/..."
                    value={createMapsUrl}
                    onChange={(e) => setCreateMapsUrl(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 transition-all text-sm"
                    id="create-maps-url-input"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">Max Jugadores</label>
                    <input
                      type="number"
                      disabled
                      value={createMaxPlayers}
                      className="w-full px-3.5 py-2.5 bg-gray-950 border border-gray-900 rounded-xl text-gray-600 font-bold text-sm cursor-not-allowed"
                    />
                    <span className="text-[9px] text-gray-600 uppercase font-bold">Determinado por cancha</span>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">SR Esperado</label>
                    <input
                      type="number"
                      required
                      min="100"
                      max="3000"
                      value={createExpectedSR}
                      onChange={(e) => setCreateExpectedSR(Number(e.target.value))}
                      className="w-full px-3.5 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 transition-all text-sm"
                      id="create-sr-input"
                    />
                    <span className="text-[9px] text-gray-500 uppercase font-bold">Tu SR actual: {user.skillRating}</span>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={creating}
                  className="w-full py-3.5 bg-green-500 hover:bg-green-400 text-black font-black uppercase tracking-tighter transition-colors rounded-xl shadow-lg shadow-green-500/20 italic text-sm flex items-center justify-center disabled:opacity-50"
                  id="create-room-submit-btn"
                >
                  {creating ? 'Iniciando...' : 'Iniciar Convocatoria'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- EDIT PROFILE MODAL --- */}
      <AnimatePresence>
        {showProfileModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" id="profile-modal-backdrop">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-[#151B22] rounded-3xl max-w-md w-full shadow-2xl border border-gray-800 overflow-hidden relative z-50 text-white"
              id="profile-modal"
            >
              <div className="bg-gradient-to-r from-green-600 to-emerald-700 px-6 py-4 flex justify-between items-center text-white border-b border-gray-800">
                <div className="flex items-center space-x-2">
                  <Settings className="w-5 h-5 text-green-200" />
                  <h3 className="font-extrabold font-display text-base">Configuración de Jugador</h3>
                </div>
                <button 
                  onClick={() => setShowProfileModal(false)}
                  className="text-white/80 hover:text-white p-1 hover:bg-white/10 rounded-lg transition-colors"
                  id="close-profile-modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {profileError && (
                <div className="p-4 bg-rose-500/10 border-b border-rose-500/20 text-rose-400 text-xs font-semibold flex items-center">
                  <ShieldAlert className="w-4 h-4 mr-2" />
                  <span>{profileError}</span>
                </div>
              )}

              <form onSubmit={handleUpdateProfile} className="p-6 space-y-4" id="profile-edit-form">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">Tu Nombre / Apodo</label>
                  <input
                    type="text"
                    required
                    value={profileName}
                    onChange={(e) => {
                      const filtered = e.target.value.replace(/[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑüÜ\s'\-\"“”.]/g, '');
                      setProfileName(filtered);
                    }}
                    className="w-full px-3.5 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 transition-all text-sm"
                    id="profile-name-input"
                  />
                </div>

                {/* Ubicación (Departamento / Provincia / Distrito) */}
                <div className="space-y-3 pt-1 border-t border-gray-800/50" id="profile-location-group">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block flex items-center">
                    <MapPin className="w-4 h-4 mr-1 text-green-500" />
                    Tu Ubicación
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {/* Departamento */}
                    <div className="space-y-1">
                      <span className="text-[8px] font-bold text-gray-400 block uppercase">Dpto.</span>
                      <select
                        value={profileDept}
                        onChange={(e) => {
                          setProfileDept(e.target.value);
                          setProfileProv('');
                          setProfileDist('');
                        }}
                        className="w-full px-2 py-1.5 bg-gray-950 border border-gray-800 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 text-xs transition-all"
                      >
                        <option value="">Elegir...</option>
                        {PERU_LOCATIONS.map((dept) => (
                          <option key={dept.name} value={dept.name}>{dept.name}</option>
                        ))}
                      </select>
                    </div>

                    {/* Provincia */}
                    <div className="space-y-1">
                      <span className="text-[8px] font-bold text-gray-400 block uppercase">Prov.</span>
                      <select
                        disabled={!profileDept}
                        value={profileProv}
                        onChange={(e) => {
                          setProfileProv(e.target.value);
                          setProfileDist('');
                        }}
                        className="w-full px-2 py-1.5 bg-gray-950 border border-gray-800 disabled:border-gray-900 disabled:text-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 text-xs transition-all"
                      >
                        <option value="">Elegir...</option>
                        {profileProvincesList.map((prov) => (
                          <option key={prov.name} value={prov.name}>{prov.name}</option>
                        ))}
                      </select>
                    </div>

                    {/* Distrito */}
                    <div className="space-y-1">
                      <span className="text-[8px] font-bold text-gray-400 block uppercase">Dist.</span>
                      <select
                        disabled={!profileProv}
                        value={profileDist}
                        onChange={(e) => setProfileDist(e.target.value)}
                        className="w-full px-2 py-1.5 bg-gray-950 border border-gray-800 disabled:border-gray-900 disabled:text-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 text-xs transition-all"
                      >
                        <option value="">Elegir...</option>
                        {profileDistrictsList.map((dist) => (
                          <option key={dist} value={dist}>{dist}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 pt-1">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">Posición Preferida</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(['GK', 'DEF', 'MID', 'FWD'] as Position[]).map((pos) => (
                      <button
                        key={pos}
                        type="button"
                        onClick={() => setProfilePosition(pos)}
                        className={`p-3 rounded-xl text-left border transition-all text-xs font-bold flex flex-col justify-between ${
                          profilePosition === pos
                            ? 'border-green-500 bg-green-500/10 text-white'
                            : 'border-gray-800 text-gray-400 hover:border-gray-700 bg-gray-950'
                        }`}
                        id={`profile-pos-select-${pos}`}
                      >
                        <span className={`text-[9px] px-1.5 py-0.5 rounded font-black uppercase tracking-wide inline-block mb-1 ${
                          pos === 'GK' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                          pos === 'DEF' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' :
                          pos === 'MID' ? 'bg-green-500/10 text-green-400 border border-green-500/20' :
                          'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        }`}>
                          {pos}
                        </span>
                        <span>{positionsLabels[pos]}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={updatingProfile}
                  className="w-full py-3.5 bg-green-500 hover:bg-green-400 text-black font-black uppercase tracking-tighter transition-colors rounded-xl shadow-lg shadow-green-500/20 italic text-sm flex items-center justify-center disabled:opacity-50"
                  id="profile-submit-btn"
                >
                  {updatingProfile ? 'Guardando...' : 'Guardar Cambios'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- SUPABASE SETUP MODAL --- */}
      <AnimatePresence>
        {showSupabaseModal && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm" id="supabase-modal-backdrop">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              className="bg-[#151B22] rounded-3xl max-w-lg w-full shadow-2xl border border-gray-800 overflow-hidden relative z-50 text-white"
              id="supabase-modal"
            >
              <div className="bg-gradient-to-r from-emerald-600 to-green-700 px-6 py-4 flex justify-between items-center text-white border-b border-gray-800">
                <div className="flex items-center space-x-2">
                  <div className={`w-2.5 h-2.5 rounded-full ${supabaseStatus?.connection ? 'bg-green-400 animate-pulse' : 'bg-amber-400'}`} />
                  <h3 className="font-extrabold font-display text-base">Sincronización Supabase Cloud</h3>
                </div>
                <button 
                  onClick={() => setShowSupabaseModal(false)}
                  className="text-white/80 hover:text-white p-1 hover:bg-white/10 rounded-lg transition-colors"
                  id="close-supabase-modal"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 space-y-4">
                <div className="bg-gray-950 p-4 rounded-2xl border border-gray-800 space-y-2">
                  <h4 className="text-[10px] font-bold text-green-400 uppercase tracking-widest">Información del Proyecto</h4>
                  
                  <div className="grid grid-cols-1 gap-2 text-xs">
                    <div className="flex justify-between items-center py-1 border-b border-gray-900/60">
                      <span className="text-gray-500 font-bold uppercase text-[9px]">Proyecto</span>
                      <span className="font-mono text-white text-[11px]">pelotalimpia ({supabaseStatus?.connection ? 'xhagynzaknkhsonzicvq' : 'xhagyn...'})</span>
                    </div>
                    <div className="flex justify-between items-center py-1 border-b border-gray-900/60">
                      <span className="text-gray-500 font-bold uppercase text-[9px]">Endpoint URL</span>
                      <span className="font-mono text-gray-300 text-[10px] truncate max-w-[220px]" title={supabaseStatus?.url}>
                        {supabaseStatus?.url}
                      </span>
                    </div>
                    <div className="flex justify-between items-center py-1 border-b border-gray-900/60">
                      <span className="text-gray-500 font-bold uppercase text-[9px]">Anon API Key</span>
                      <span className="font-mono text-gray-400 text-[10px] truncate max-w-[220px]">
                        {supabaseStatus?.key}
                      </span>
                    </div>
                    <div className="flex justify-between items-center py-1">
                      <span className="text-gray-500 font-bold uppercase text-[9px]">Estado Conexión</span>
                      <span className={`font-bold uppercase text-[10px] ${supabaseStatus?.connection ? 'text-emerald-400' : 'text-amber-500'}`}>
                        {supabaseStatus?.connection ? '● CONECTADO' : '● SIN CONECTAR / FALLBACK LOCAL'}
                      </span>
                    </div>
                  </div>
                </div>

                {!supabaseStatus?.connection && (
                  <div className="p-3.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs rounded-xl space-y-1">
                    <p className="font-black uppercase tracking-tight text-[11px]">⚠️ Tablas faltantes en Supabase</p>
                    <p className="text-gray-400 text-[10px] leading-relaxed uppercase font-semibold">
                      El cliente Supabase está inicializado pero no logramos consultar las tablas. Ejecuta el script SQL abajo en tu editor de Supabase para habilitar la base de datos cloud.
                    </p>
                  </div>
                )}

                {supabaseStatus?.connection && (
                  <div className="p-3.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-xl space-y-1">
                    <p className="font-black uppercase tracking-tight text-[11px]">✅ Sincronización en tiempo real activa</p>
                    <p className="text-gray-400 text-[10px] leading-relaxed uppercase font-semibold">
                      Todas tus acciones de juego, convocatorias, chats y estadísticas se replican instantáneamente en tu nube de Supabase.
                    </p>
                  </div>
                )}

                {/* Tables Status */}
                <div className="bg-gray-950 p-4 rounded-2xl border border-gray-800 space-y-2">
                  <h4 className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Verificación de Tablas</h4>
                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div className="flex items-center justify-between p-2 bg-[#151B22]/50 border border-gray-900 rounded-xl">
                      <span className="font-bold text-gray-400 uppercase">users</span>
                      <span className={`text-[9px] font-black ${supabaseStatus?.tables?.users ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {supabaseStatus?.tables?.users ? 'OK' : 'N/A'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-[#151B22]/50 border border-gray-900 rounded-xl">
                      <span className="font-bold text-gray-400 uppercase">rooms</span>
                      <span className={`text-[9px] font-black ${supabaseStatus?.tables?.rooms ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {supabaseStatus?.tables?.rooms ? 'OK' : 'N/A'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-[#151B22]/50 border border-gray-900 rounded-xl">
                      <span className="font-bold text-gray-400 uppercase">messages</span>
                      <span className={`text-[9px] font-black ${supabaseStatus?.tables?.messages ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {supabaseStatus?.tables?.messages ? 'OK' : 'N/A'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-[#151B22]/50 border border-gray-900 rounded-xl">
                      <span className="font-bold text-gray-400 uppercase">history</span>
                      <span className={`text-[9px] font-black ${supabaseStatus?.tables?.history ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {supabaseStatus?.tables?.history ? 'OK' : 'N/A'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* SQL Script to copy */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">Script de Inicialización SQL</label>
                    <button
                      type="button"
                      onClick={() => {
                        if (supabaseStatus?.sql) {
                          navigator.clipboard.writeText(supabaseStatus.sql);
                          alert('¡Script SQL copiado al portapapeles!');
                        }
                      }}
                      className="text-[9px] font-black text-green-400 hover:text-green-300 transition-colors uppercase cursor-pointer"
                    >
                      Copiar Script
                    </button>
                  </div>
                  <pre className="p-3 bg-gray-950 border border-gray-800 rounded-xl text-[10px] font-mono text-gray-400 max-h-24 overflow-y-auto select-all leading-normal">
                    {supabaseStatus?.sql || '-- Cargando SQL...'}
                  </pre>
                  <p className="text-[8px] text-gray-600 font-bold uppercase tracking-wide">
                    Pega este script en el editor SQL de tu panel de Supabase y haz click en "Run".
                  </p>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={fetchSupabaseStatus}
                    disabled={loadingSupabase}
                    className="flex-1 py-3 bg-[#151B22] hover:bg-gray-800 border border-gray-800 text-white font-extrabold text-xs uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${loadingSupabase ? 'animate-spin' : ''}`} />
                    Verificar
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowSupabaseModal(false)}
                    className="flex-1 py-3 bg-green-500 hover:bg-green-400 text-black font-black text-xs uppercase tracking-wider rounded-xl transition-all italic cursor-pointer"
                  >
                    Cerrar Panel
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Drawer overlay for Mobile Sidebar (Profile & Match History) */}
      <AnimatePresence>
        {showMobileSidebar && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMobileSidebar(false)}
              className="fixed inset-0 bg-black z-40 lg:hidden"
              id="mobile-sidebar-backdrop"
            />
            
            {/* Drawer Body */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 26, stiffness: 220 }}
              className="fixed right-0 top-0 bottom-0 w-[85%] max-w-sm bg-[#0B0F13] border-l border-gray-800 p-6 z-50 overflow-y-auto lg:hidden flex flex-col gap-6"
              id="mobile-sidebar-drawer"
            >
              {/* Drawer Header */}
              <div className="flex justify-between items-center pb-2 border-b border-gray-800/80">
                <div className="flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-green-500" />
                  <span className="font-black text-xs text-gray-400 uppercase italic tracking-widest">Mi Perfil y Stats</span>
                </div>
                <button
                  onClick={() => setShowMobileSidebar(false)}
                  className="p-1.5 bg-gray-950 hover:bg-gray-800 text-gray-400 hover:text-white rounded-xl border border-gray-800 transition-colors"
                  aria-label="Cerrar"
                  id="close-mobile-sidebar"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Sidebar Content rendered in drawer */}
              <div className="space-y-6">
                {sidebarContent}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

    </div>
  );
}
