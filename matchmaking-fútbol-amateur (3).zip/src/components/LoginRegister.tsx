import React, { useState, useEffect } from 'react';
import { apiFetch, setToken, saveCachedUser } from '../lib/api';
import { User, Position } from '../types';
import { Shield, Mail, Lock, User as UserIcon, Activity, Trophy, MapPin, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';
import { PERU_LOCATIONS } from '../lib/locations';

interface LoginRegisterProps {
  onAuthSuccess: (user: User) => void;
  initialIsLogin?: boolean;
  onBackToLanding?: () => void;
}

export default function LoginRegister({ onAuthSuccess, initialIsLogin = true, onBackToLanding }: LoginRegisterProps) {
  const [isLogin, setIsLogin] = useState(initialIsLogin);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [preferredPosition, setPreferredPosition] = useState<Position>('MID');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [loading, setLoading] = useState(false);

  // Synchronize state when landing page redirects again
  useEffect(() => {
    setIsLogin(initialIsLogin);
    setError('');
    setSuccessMessage('');
  }, [initialIsLogin]);

  // Cascading location states
  const [selectedDept, setSelectedDept] = useState('');
  const [selectedProv, setSelectedProv] = useState('');
  const [selectedDist, setSelectedDist] = useState('');

  const departmentData = PERU_LOCATIONS.find(d => d.name === selectedDept);
  const provincesList = departmentData ? departmentData.provinces : [];
  const provinceData = provincesList.find(p => p.name === selectedProv);
  const districtsList = provinceData ? provinceData.districts : [];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    const trimmedEmail = email.trim();
    const trimmedPassword = password; // Keep password spacing as entered, but we can check its length

    // 1. Email validation (both login and register)
    if (!trimmedEmail) {
      setError('Por favor, ingresa tu correo electrónico.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      setError('El correo electrónico no tiene un formato válido (ejemplo@dominio.com).');
      return;
    }

    // 2. Password validation (both login and register)
    if (!trimmedPassword) {
      setError('Por favor, ingresa tu contraseña.');
      return;
    }

    if (!isLogin) {
      // 3. Name validation (Register only)
      const trimmedName = name.trim();
      if (!trimmedName) {
        setError('Por favor, ingresa tu nombre completo o apodo.');
        return;
      }
      if (trimmedName.length < 3) {
        setError('El nombre o apodo debe tener al menos 3 caracteres.');
        return;
      }
      if (trimmedName.length > 40) {
        setError('El nombre o apodo no debe superar los 40 caracteres.');
        return;
      }

      // Allowed characters in name: letters (with accents), numbers, spaces, hyphens, periods, and single/double quotes
      const nameRegex = /^[a-zA-Z0-9áéíóúÁÉÍÓÚñÑüÜ\s'\-\"“”.]+$/;
      if (!nameRegex.test(trimmedName)) {
        setError('El nombre solo puede contener letras, números, espacios, guiones, puntos y comillas para tu apodo.');
        return;
      }

      // 4. Password validation (Register only)
      if (trimmedPassword.length < 6) {
        setError('La contraseña debe tener al menos 6 caracteres por seguridad.');
        return;
      }

      // 5. Location validation (Register only)
      if (!selectedDept || !selectedProv || !selectedDist) {
        setError('Por favor, selecciona tu ubicación completa (Departamento, Provincia y Distrito).');
        return;
      }
    }

    setLoading(true);

    try {
      if (isLogin) {
        const response = await apiFetch<{ user: User; token: string }>('/auth/login', {
          method: 'POST',
          body: JSON.stringify({ email: trimmedEmail, password: trimmedPassword }),
        });
        setToken(response.token);
        saveCachedUser(response.user);
        onAuthSuccess(response.user);
      } else {
        const response = await apiFetch<{ user: User; token: string }>('/auth/register', {
          method: 'POST',
          body: JSON.stringify({
            email: trimmedEmail,
            password: trimmedPassword,
            name: name.trim(),
            preferredPosition,
            department: selectedDept || undefined,
            province: selectedProv || undefined,
            district: selectedDist || undefined,
          }),
        });
        setSuccessMessage('¡Usuario registrado con éxito! Iniciando sesión...');
        
        // Store auth data directly
        setToken(response.token);
        saveCachedUser(response.user);
        
        // Redirect to dashboard after a brief delay
        setTimeout(() => {
          onAuthSuccess(response.user);
        }, 1500);
      }
    } catch (err: any) {
      setError(err.message || 'Error de autenticación');
    } finally {
      setLoading(false);
    }
  };

  const positions: Array<{ value: Position; label: string; desc: string; color: string }> = [
    { value: 'GK', label: 'Portero (GK)', desc: 'Evita goles rivales y ordena al equipo.', color: 'from-amber-500/20 to-yellow-500/5 text-amber-400 border-amber-500/30' },
    { value: 'DEF', label: 'Defensa (DEF)', desc: 'Corta jugadas y gana duelos físicos.', color: 'from-blue-500/20 to-indigo-500/5 text-blue-400 border-blue-500/30' },
    { value: 'MID', label: 'Mediocampista (MID)', desc: 'Distribuye juego y controla el ritmo.', color: 'from-emerald-500/20 to-teal-500/5 text-emerald-400 border-emerald-500/30' },
    { value: 'FWD', label: 'Delantero (FWD)', desc: 'Anota goles y define partidos.', color: 'from-rose-500/20 to-red-500/5 text-rose-400 border-rose-500/30' },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-[#0B0F13] relative overflow-hidden text-gray-100" id="auth-container">
      {/* Dynamic Soccer Field Background Accents - Bento style */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="auth-grid" width="30" height="30" patternUnits="userSpaceOnUse">
              <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(255, 255, 255, 0.05)" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#auth-grid)" />
        </svg>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] border border-green-500/10 rounded-full" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 border-2 border-green-500/10 rounded-full" />
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-lg bg-[#151B22] rounded-3xl shadow-2xl border border-gray-800 p-8 relative z-10 pt-12"
        id="auth-card"
      >
        {onBackToLanding && (
          <button
            type="button"
            onClick={onBackToLanding}
            className="absolute top-5 left-6 text-xs font-bold text-gray-500 hover:text-green-400 transition-colors flex items-center gap-1.5 uppercase tracking-wider"
            id="auth-back-to-landing"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Volver al Inicio</span>
          </button>
        )}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 justify-center mb-4">
            <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center text-black font-black text-xl italic">SF</div>
            <span className="text-xl font-bold tracking-tight text-white italic underline underline-offset-4 decoration-green-500">STRIKER.FORCE</span>
          </div>
          <h1 className="text-3xl font-black font-display uppercase italic tracking-tighter text-white">
            {isLogin ? 'Iniciar Sesión' : 'Registrar Jugador'}
          </h1>
          <p className="text-gray-400 text-xs mt-2 font-medium tracking-wider uppercase">
            {isLogin 
              ? 'Ingresa a la red de matchmaking táctico' 
              : 'Regístrate para calcular tu Skill Rating (SR)'}
          </p>
        </div>

        {error && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mb-6 p-4 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-400 text-xs font-semibold flex items-center"
            id="auth-error"
          >
            <Shield className="w-4 h-4 mr-2 shrink-0 text-rose-500" />
            <span>{error}</span>
          </motion.div>
        )}

        {successMessage && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-400 text-xs font-semibold flex items-center"
            id="auth-success"
          >
            <CheckCircle2 className="w-4 h-4 mr-2 shrink-0 text-emerald-500" />
            <span>{successMessage}</span>
          </motion.div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5" id="auth-form">
          {!isLogin && (
            <div className="space-y-1.5" id="field-group-name">
              <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">
                Nombre Completo o Apodo
              </label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-gray-500">
                  <UserIcon className="w-5 h-5" />
                </span>
                <input
                type="text"
                required
                placeholder='Ej: Carlos "El Tanque" P.'
                value={name}
                onChange={(e) => {
                  const filtered = e.target.value.replace(/[^a-zA-Z0-9áéíóúÁÉÍÓÚñÑüÜ\s'\-\"“”.]/g, '');
                  setName(filtered);
                }}
                className="w-full pl-11 pr-4 py-3 bg-gray-950 border border-gray-800 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 transition-all text-sm"
                id="auth-name-input"
              />
              </div>
            </div>
          )}

          <div className="space-y-1.5" id="field-group-email">
            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">
              Correo Electrónico
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-gray-500">
                <Mail className="w-5 h-5" />
              </span>
              <input
                type="email"
                required
                placeholder="correo@ejemplo.com"
                value={email}
                onChange={(e) => {
                  const filtered = e.target.value.replace(/[^a-zA-Z0-9@._\-+]/g, '');
                  setEmail(filtered);
                }}
                className="w-full pl-11 pr-4 py-3 bg-gray-950 border border-gray-800 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 transition-all text-sm"
                id="auth-email-input"
              />
            </div>
          </div>

          <div className="space-y-1.5" id="field-group-password">
            <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 block">
              Contraseña
            </label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-gray-500">
                <Lock className="w-5 h-5" />
              </span>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-11 pr-4 py-3 bg-gray-950 border border-gray-800 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 transition-all text-sm"
                id="auth-password-input"
              />
            </div>
          </div>

          {!isLogin && (
            <div className="space-y-3 pt-2" id="field-group-location">
              <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 flex items-center">
                <MapPin className="w-4 h-4 mr-1 text-green-500" />
                Ubicación (Departamento / Provincia / Distrito)
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Departamento */}
                <div>
                  <span className="text-[8px] font-bold text-gray-400 block uppercase mb-1">Dpto.</span>
                  <select
                    value={selectedDept}
                    onChange={(e) => {
                      setSelectedDept(e.target.value);
                      setSelectedProv('');
                      setSelectedDist('');
                    }}
                    className="w-full px-2.5 py-2 bg-gray-950 border border-gray-800 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 text-xs transition-all"
                  >
                    <option value="">Elegir...</option>
                    {PERU_LOCATIONS.map((dept) => (
                      <option key={dept.name} value={dept.name}>{dept.name}</option>
                    ))}
                  </select>
                </div>

                {/* Provincia */}
                <div>
                  <span className="text-[8px] font-bold text-gray-400 block uppercase mb-1">Prov.</span>
                  <select
                    value={selectedProv}
                    disabled={!selectedDept}
                    onChange={(e) => {
                      setSelectedProv(e.target.value);
                      setSelectedDist('');
                    }}
                    className="w-full px-2.5 py-2 bg-gray-950 border border-gray-800 disabled:border-gray-900 disabled:text-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 text-xs transition-all"
                  >
                    <option value="">Elegir...</option>
                    {provincesList.map((prov) => (
                      <option key={prov.name} value={prov.name}>{prov.name}</option>
                    ))}
                  </select>
                </div>

                {/* Distrito */}
                <div>
                  <span className="text-[8px] font-bold text-gray-400 block uppercase mb-1">Dist.</span>
                  <select
                    value={selectedDist}
                    disabled={!selectedProv}
                    onChange={(e) => setSelectedDist(e.target.value)}
                    className="w-full px-2.5 py-2 bg-gray-950 border border-gray-800 disabled:border-gray-900 disabled:text-gray-600 rounded-xl text-white focus:outline-none focus:ring-2 focus:ring-green-500/10 focus:border-green-500 text-xs transition-all"
                  >
                    <option value="">Elegir...</option>
                    {districtsList.map((dist) => (
                      <option key={dist} value={dist}>{dist}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          )}

          {!isLogin && (
            <div className="space-y-3 pt-2" id="field-group-position">
              <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 flex items-center">
                <Activity className="w-4 h-4 mr-1 text-green-500" />
                Posición Preferida
              </label>
              <div className="grid grid-cols-2 gap-3">
                {positions.map((pos) => (
                  <button
                    key={pos.value}
                    type="button"
                    onClick={() => setPreferredPosition(pos.value)}
                    className={`p-3 rounded-xl text-left border transition-all duration-200 flex flex-col justify-between ${
                      preferredPosition === pos.value
                        ? 'border-green-500 bg-green-500/10 ring-2 ring-green-500/20'
                        : 'border-gray-800 hover:border-gray-700 bg-gray-950'
                    }`}
                    id={`pos-select-${pos.value}`}
                  >
                    <span className={`text-[9px] px-2 py-0.5 rounded font-bold uppercase tracking-wide inline-block mb-1 bg-gradient-to-r ${pos.color}`}>
                      {pos.value}
                    </span>
                    <span className="font-bold text-xs text-white">{pos.label}</span>
                    <span className="text-[9px] text-gray-500 mt-1 leading-tight">{pos.desc}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-4 bg-green-500 hover:bg-green-400 text-black font-black uppercase tracking-tighter transition-colors rounded-xl shadow-lg shadow-green-500/20 italic text-sm flex items-center justify-center disabled:opacity-50"
            id="auth-submit-btn"
          >
            {loading ? (
              <span className="flex items-center">
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-black" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                PROCESANDO...
              </span>
            ) : (
              isLogin ? 'Ingresar a la Plataforma' : 'Crear Cuenta y Perfil'
            )}
          </button>
        </form>

        <div className="mt-6 pt-6 border-t border-gray-800 text-center text-xs text-gray-400 uppercase tracking-wider">
          {isLogin ? (
            <p>
              ¿No tienes un perfil creado?{' '}
              <button
                type="button"
                onClick={() => {
                  setIsLogin(false);
                  setError('');
                  setSuccessMessage('');
                }}
                className="text-green-400 font-bold hover:text-green-300 ml-1"
                id="toggle-register-btn"
              >
                Regístrate aquí
              </button>
            </p>
          ) : (
            <p>
              ¿Ya tienes una cuenta registrada?{' '}
              <button
                type="button"
                onClick={() => {
                  setIsLogin(true);
                  setError('');
                  setSuccessMessage('');
                }}
                className="text-green-400 font-bold hover:text-green-300 ml-1"
                id="toggle-login-btn"
              >
                Inicia sesión
              </button>
            </p>
          )}
        </div>
      </motion.div>
    </div>
  );
}
