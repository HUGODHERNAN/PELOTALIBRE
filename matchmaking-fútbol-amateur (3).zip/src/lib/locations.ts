export interface Province {
  name: string;
  districts: string[];
}

export interface Department {
  name: string;
  provinces: Province[];
}

export const PERU_LOCATIONS: Department[] = [
  {
    name: 'Arequipa',
    provinces: [
      {
        name: 'Arequipa',
        districts: [
          'Arequipa',
          'Alto Selva Alegre',
          'Cayma',
          'Cerro Colorado',
          'Characato',
          'Chiguata',
          'Jacobo Hunter',
          'José Luis Bustamante y Rivero',
          'La Joya',
          'Mariano Melgar',
          'Miraflores',
          'Mollebaya',
          'Paucarpata',
          'Pocsi',
          'Polobaya',
          'Quequeña',
          'Sabandía',
          'Sachaca',
          'San Juan de Siguas',
          'San Juan de Tarucani',
          'Santa Isabel de Siguas',
          'Santa Rita de Siguas',
          'Socabaya',
          'Tiabaya',
          'Uchumayo',
          'Vítor',
          'Yanahuara',
          'Yarabamba',
          'Yura'
        ]
      },
      {
        name: 'Camaná',
        districts: [
          'Camaná',
          'José María Quimper',
          'Mariano Nicolás Valcárcel',
          'Mariscal Cáceres',
          'Nicolás de Piérola',
          'Ocoña',
          'Quilca',
          'Samuel Pastor'
        ]
      },
      {
        name: 'Caravelí',
        districts: [
          'Caravelí',
          'Acarí',
          'Atico',
          'Atiquipa',
          'Bella Unión',
          'Cahuacho',
          'Chala',
          'Cháparra',
          'Huanuhuanu',
          'Jaquí',
          'Lomas',
          'Quicacha',
          'Yauca'
        ]
      },
      {
        name: 'Castilla',
        districts: [
          'Aplao',
          'Andagua',
          'Ayo',
          'Chachas',
          'Chilcaymarca',
          'Choco',
          'Huancarqui',
          'Machaguay',
          'Orcopampa',
          'Pampacolca',
          'Tipán',
          'Uñón',
          'Uraca',
          'Viraco'
        ]
      },
      {
        name: 'Caylloma',
        districts: [
          'Chivay',
          'Achoma',
          'Cabanaconde',
          'Callalli',
          'Caylloma',
          'Coporaque',
          'Huambo',
          'Huanca',
          'Ichupampa',
          'Lari',
          'Lluta',
          'Maca',
          'Madrigal',
          'Majes',
          'San Antonio de Chuca',
          'Sibayo',
          'Tapay',
          'Tisco',
          'Tuti',
          'Yanque'
        ]
      },
      {
        name: 'Condesuyos',
        districts: [
          'Chuquibamba',
          'Andaray',
          'Cayarani',
          'Chichas',
          'Iray',
          'Río Grande',
          'Salamanca',
          'Yanaquihua'
        ]
      },
      {
        name: 'Islay',
        districts: [
          'Mollendo',
          'Cocachacra',
          'Deán Valdivia',
          'Islay',
          'Mejía',
          'Punta de Bombón'
        ]
      },
      {
        name: 'La Unión',
        districts: [
          'Cotahuasi',
          'Alca',
          'Charcana',
          'Huaynacotas',
          'Pampamarca',
          'Puyca',
          'Quechualla',
          'Sayla',
          'Tauría',
          'Tomepampa',
          'Toro'
        ]
      }
    ]
  },
  {
    name: 'Lima',
    provinces: [
      {
        name: 'Lima',
        districts: [
          'Lima (Cercado)',
          'Ancón',
          'Ate',
          'Barranco',
          'Breña',
          'Carabayllo',
          'Chaclacayo',
          'Chorrillos',
          'Cieneguilla',
          'Comas',
          'El Agustino',
          'Independencia',
          'Jesús María',
          'La Molina',
          'La Victoria',
          'Lince',
          'Los Olivos',
          'Lurigancho-Chosica',
          'Lurín',
          'Magdalena del Mar',
          'Miraflores',
          'Pachacámac',
          'Pucusana',
          'Pueblo Libre',
          'Puente Piedra',
          'Punta Hermosa',
          'Punta Negra',
          'Rímac',
          'San Bartolo',
          'San Borja',
          'San Isidro',
          'San Juan de Lurigancho',
          'San Juan de Miraflores',
          'San Luis',
          'San Martín de Porres',
          'San Miguel',
          'Santa Anita',
          'Santa María del Mar',
          'Santa Rosa',
          'Santiago de Surco',
          'Surquillo',
          'Villa El Salvador',
          'Villa María del Triunfo'
        ]
      },
      {
        name: 'Barranca',
        districts: [
          'Barranca',
          'Paramonga',
          'Pativilca',
          'Puerto Supe',
          'Supe'
        ]
      },
      {
        name: 'Cajatambo',
        districts: [
          'Cajatambo',
          'Copa',
          'Gorgor',
          'Huancapón',
          'Manás'
        ]
      },
      {
        name: 'Canta',
        districts: [
          'Canta',
          'Arahuay',
          'Huamantanga',
          'Huaros',
          'Lachaqui',
          'San Buenaventura',
          'Santa Rosa de Quives'
        ]
      },
      {
        name: 'Cañete',
        districts: [
          'San Vicente de Cañete',
          'Asia',
          'Calango',
          'Cerro Azul',
          'Chilca',
          'Coayllo',
          'Imperial',
          'Lunahuaná',
          'Mala',
          'Nuevo Imperial',
          'Pacarán',
          'Quilmaná',
          'San Antonio',
          'San Luis',
          'Santa Cruz de Flores',
          'Zúñiga'
        ]
      },
      {
        name: 'Huaral',
        districts: [
          'Huaral',
          'Atavillos Alto',
          'Atavillos Bajo',
          'Aucallama',
          'Chancay',
          'Ihuarí',
          'Lampían',
          'Pacaraos',
          'San Miguel de Acos',
          'Santa Cruz de Andamarca',
          'Sumbilca',
          'Veintisiete de Noviembre'
        ]
      },
      {
        name: 'Huarochirí',
        districts: [
          'Matucana',
          'Antioquía',
          'Callahuanca',
          'Carampoma',
          'Chicla',
          'Cuenca',
          'Huachupampa',
          'Huanza',
          'Huarochirí',
          'Lahuaytambo',
          'Langa',
          'Laraos',
          'Mariatana',
          'Ricardo Palma',
          'San Andrés de Tupicocha',
          'San Antonio',
          'San Bartolomé',
          'San Damián',
          'San Juan de Iris',
          'San Juan de Tantaranche',
          'San Lorenzo de Quinti',
          'San Mateo',
          'San Mateo de Otao',
          'San Pedro de Casta',
          'San Pedro de Huancayre',
          'Sangallaya',
          'Santa Cruz de Cocachacra',
          'Santa Eulalia',
          'Santiago de Anchucaya',
          'Santiago de Tuna',
          'Santo Domingo de los Olleros',
          'Surco'
        ]
      },
      {
        name: 'Huaura',
        districts: [
          'Huacho',
          'Ámbar',
          'Caleta de Carquín',
          'Checras',
          'Hualmay',
          'Huaura',
          'Leoncio Prado',
          'Paccho',
          'Santa Leonor',
          'Santa María',
          'Sayán',
          'Végueta'
        ]
      },
      {
        name: 'Oyón',
        districts: [
          'Oyón',
          'Andajes',
          'Caujul',
          'Cochamarca',
          'Naván',
          'Pachangara'
        ]
      },
      {
        name: 'Yauyos',
        districts: [
          'Yauyos',
          'Alis',
          'Ayauca',
          'Ayaviri',
          'Azángaro',
          'Cacra',
          'Carania',
          'Catahuasi',
          'Chocos',
          'Cochas',
          'Colonia',
          'Hongos',
          'Huampará',
          'Huancaya',
          'Huangáscar',
          'Huantán',
          'Huañec',
          'Laraos',
          'Lincha',
          'Madean',
          'Miraflores',
          'Omas',
          'Putinza',
          'Quinches',
          'Quinocay',
          'San Joaquín',
          'San Pedro de Pilas',
          'Tanta',
          'Tauripampa',
          'Tomas',
          'Tupe',
          'Viñac',
          'Vitis'
        ]
      }
    ]
  }
];
