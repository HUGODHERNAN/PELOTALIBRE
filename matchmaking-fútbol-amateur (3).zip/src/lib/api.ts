import { io, Socket } from 'socket.io-client';

const API_BASE = '/api';

// Token helpers
export function setToken(token: string) {
  localStorage.setItem('matchmaker_token', token);
}

export function getToken(): string | null {
  return localStorage.getItem('matchmaker_token');
}

export function removeToken() {
  localStorage.removeItem('matchmaker_token');
  localStorage.removeItem('matchmaker_user');
}

export function getHeaders(): HeadersInit {
  const token = getToken();
  return {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
  };
}

// Socket instance helper
let socket: Socket | null = null;

export function getSocket(): Socket {
  if (!socket) {
    // In production or development, the server is running on the same host and port 3000
    socket = io({
      autoConnect: true,
      transports: ['websocket', 'polling'],
    });
  }
  return socket;
}

export function disconnectSocket() {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
}

// API functions
export async function apiFetch<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const url = `${API_BASE}${endpoint}`;
  const response = await fetch(url, {
    ...options,
    headers: {
      ...getHeaders(),
      ...options.headers,
    },
  });

  let data: any;
  const contentType = response.headers.get('content-type');
  if (contentType && contentType.includes('application/json')) {
    data = await response.json();
  } else {
    const text = await response.text();
    data = { error: text || 'Algo salió mal. Por favor intenta de nuevo.' };
  }

  if (!response.ok) {
    throw new Error(data.error || 'Algo salió mal. Por favor intenta de nuevo.');
  }
  return data as T;
}

// User Profile Cache helper
export function saveCachedUser(user: any) {
  localStorage.setItem('matchmaker_user', JSON.stringify(user));
}

export function getCachedUser(): any | null {
  const stored = localStorage.getItem('matchmaker_user');
  if (!stored) return null;
  try {
    return JSON.parse(stored);
  } catch {
    return null;
  }
}
