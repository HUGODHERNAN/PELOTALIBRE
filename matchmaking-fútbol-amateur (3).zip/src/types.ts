export type Position = 'GK' | 'DEF' | 'MID' | 'FWD';

export type PitchType = '5v5' | '7v7' | '11v11';

export interface User {
  id: string;
  email: string;
  name: string;
  preferredPosition: Position;
  skillRating: number;
  matchesPlayed: number;
  wins: number;
  losses: number;
  draws: number;
  department?: string;
  province?: string;
  district?: string;
}

export interface PlayerInfo {
  id: string;
  name: string;
  preferredPosition: Position;
  skillRating: number;
}

export interface Room {
  id: string;
  title: string;
  creatorId: string;
  creatorName: string;
  date: string;
  time: string;
  pitchType: PitchType;
  maxPlayers: number;
  expectedSR: number;
  players: string[]; // List of user IDs
  teamA: string[];   // List of user IDs in Team A (Local)
  teamB: string[];   // List of user IDs in Team B (Visitante)
  state: 'lobby' | 'started' | 'finished';
  scoreA?: number;
  scoreB?: number;
  captainA?: string;
  captainB?: string;
  captainAApproved?: boolean;
  captainBApproved?: boolean;
  pendingScoreA?: number;
  pendingScoreB?: number;
  scoreApprovalState?: 'none' | 'pending_approval' | 'approved' | 'rejected';
  createdAt: string;
  department?: string;
  province?: string;
  district?: string;
  mapsUrl?: string;
}

export interface Message {
  id: string;
  roomId: string;
  userId: string;
  userName: string;
  text: string;
  createdAt: string;
}

export interface MatchHistoryItem {
  id: string;
  userId?: string; // Player ID that this history entry is computed for
  roomId: string;
  title: string;
  date: string;
  pitchType: PitchType;
  scoreA: number;
  scoreB: number;
  teamA: PlayerInfo[];
  teamB: PlayerInfo[];
  result: 'win' | 'loss' | 'draw'; // from the perspective of the player viewing their history
  srChange: number;
  timestamp: string;
}
