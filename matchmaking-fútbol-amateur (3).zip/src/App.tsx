import React, { useState, useEffect } from 'react';
import { User } from './types';
import { apiFetch, getToken, getCachedUser, saveCachedUser, disconnectSocket } from './lib/api';
import LandingPage from './components/LandingPage';
import LoginRegister from './components/LoginRegister';
import Dashboard from './components/Dashboard';
import RoomLobby from './components/RoomLobby';
import { Trophy } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [showAuth, setShowAuth] = useState(false);
  const [authIsLogin, setAuthIsLogin] = useState(true);

  // Restore session on mount
  useEffect(() => {
    const checkSession = async () => {
      const token = getToken();
      if (!token) {
        setLoading(false);
        return;
      }

      // Try loading from cache first for instantaneous UI render
      const cached = getCachedUser();
      if (cached) {
        setUser(cached);
      }

      try {
        // Fetch fresh profile data to keep state completely in sync
        const freshUser = await apiFetch<User>('/profile');
        setUser(freshUser);
        saveCachedUser(freshUser);
      } catch (err) {
        console.error('Failed to verify session, logging out', err);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    checkSession();
  }, []);

  const handleLogout = () => {
    setUser(null);
    setActiveRoomId(null);
    setShowAuth(false);
    disconnectSocket();
  };

  const handleAuthSuccess = (authenticatedUser: User) => {
    setUser(authenticatedUser);
  };

  const handleJoinRoom = (roomId: string) => {
    setActiveRoomId(roomId);
  };

  const handleLeaveRoom = async () => {
    // Return to dashboard and fetch fresh user profile (to update updated SR/history after finished match)
    setActiveRoomId(null);
    try {
      const freshUser = await apiFetch<User>('/profile');
      setUser(freshUser);
      saveCachedUser(freshUser);
    } catch (err) {
      console.error('Error refreshing profile after room exit:', err);
    }
  };

  const handleUpdateUser = (updatedUser: User) => {
    setUser(updatedUser);
    saveCachedUser(updatedUser);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white" id="app-loading-screen">
        <motion.div 
          animate={{ scale: [1, 1.1, 1], rotate: [0, 10, -10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
          className="p-4 bg-emerald-600 rounded-3xl text-white mb-4 shadow-lg shadow-emerald-500/20"
        >
          <Trophy className="w-10 h-10" />
        </motion.div>
        <h2 className="font-extrabold font-display text-xl tracking-tight">Fútbol Matchmaker</h2>
        <span className="text-xs text-slate-500 mt-2 font-mono">Cargando tu perfil...</span>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0B0F13] text-gray-100 font-sans" id="app-root-container">
      <AnimatePresence mode="wait">
        {user === null ? (
          !showAuth ? (
            <motion.div
              key="landing"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <LandingPage 
                onNavigateToAuth={(isLogin) => {
                  setAuthIsLogin(isLogin);
                  setShowAuth(true);
                }} 
              />
            </motion.div>
          ) : (
            <motion.div
              key="auth"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <LoginRegister 
                onAuthSuccess={handleAuthSuccess} 
                initialIsLogin={authIsLogin}
                onBackToLanding={() => setShowAuth(false)}
              />
            </motion.div>
          )
        ) : activeRoomId === null ? (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Dashboard 
              user={user} 
              onLogout={handleLogout} 
              onJoinRoom={handleJoinRoom}
              onUpdateUser={handleUpdateUser}
            />
          </motion.div>
        ) : (
          <motion.div
            key="room"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <RoomLobby 
              roomId={activeRoomId} 
              currentUser={user} 
              onLeaveRoom={handleLeaveRoom}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
